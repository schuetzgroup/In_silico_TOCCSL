function [fitresult, gof] = fit_density_erf(x_coo_local_nonz,DENS_local_nonz,par)
%  Data for 'untitled fit 1' fit:
%      X Input : x_coo_local_nonz
%      Y Output: DENS_local_nonz
%  Output:
%      fitresult : a fit object representing the fit.
%      gof : structure with goodness-of fit info.
%  See also FIT, CFIT, SFIT.

[xData, yData] = prepareCurveData( x_coo_local_nonz, DENS_local_nonz);

% Set up fittype and options.
% Ruprecht et. al 2009, trec should actually be par.D*trec but omitted
% since par.D is only introducing a scaling factor in the denominator
% (par.D*trec) -> trec

ft = fittype( 'rho0*(1 - 1/2*erf((x+dx/2)/sqrt(4*trec)) + 1/2*erf((x-dx/2)/sqrt(4*trec)))', 'independent', 'x', 'dependent', 'y' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Lower = [0 0 0]; % dx rho0 trec
opts.Upper = [1000 1000 1000];
opts.StartPoint = [0.515054937293625 0.571710162876675 0.549151283496572];

%% Fit model to data.
xthresh = (par.d_ap + par.edge)/2; % 4.0; % threshold for inner region for fit
xData2 = xData(xData < xthresh);
yData2 = yData(xData < xthresh);
[fitresult, gof] = fit(xData2, yData2, ft, opts );