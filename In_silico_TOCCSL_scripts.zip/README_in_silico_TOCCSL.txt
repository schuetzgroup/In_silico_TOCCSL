"TOCCSL simulation"

The file "TOCCSL_main.m" can be used as a standalone script for a single simulation run with a parameter set which can be defined within the file. Several plots will be shown when "par.plots_signal = 1".

For simulating TOCCSL experiments with a varying parameter, following Script can be used:

"loop_optimal_recovery_time_and_variation_of_main_parameter.m"


********** INPUT PARAMETER **********

The definition of simulation parameters as well as the varying parameter are defined in the struct array "par". The varying parameter "varpar" (one dimensional vector) is defined outside the loops and is assigned to the respective parameter in the "par" struct array to be varied within the loop. For the parameters "par.fluorophore" ('GFP') and the parameter "par.analysis_method" ('everything') there is currently only one option to chose.
For the diffracted laser intensity profile (par.laser_shape = 'diffraction') the script "check_laser_profile.m") can be used to check the intensity profile with Gaussian shaped edges. For this profile "par.edge" and "par.simga_diff" can be adjusted.

********** SIMULATION STRUCTURE **********

There are 3 parts in the simulation for one specific parameter set (i.e. one specific value of the varying parameter):

1) Pre-runs with varying recovery time ("var_rec") to determine the recovery time at which the maximum number of molecules are residing within the analysis region after the recovery time.

2) Additional pre-runs for determination of the analysis region radius for the t_rec which was determined in step 1.

3) Main simulation runs with analysis of the region within the cut-off radius which was determined in 2).

********** IMPORTANT CHECKS **********

In order to ensure the validity of the simulation several plots are included in the code can be checked:

*) in "analysis_roi_calculation_fit.m"
	Plot of the molecule density vs. radial coordinate: A fit is used to determine the cut-off radius for the analysis region. The agreement of the fit with the simulated (fluctuating) data can be checked. If the data looks too noisy, the number of par.n_pre-runs/par.n_addruns could be increased.

*) in "loop_optimal_recovery_time_and_variation_of_main_parameter.m"
	Plot of molecule number vs. recovery time: The fit is used to determine the recovery time with the maximum molecule number within the analysis region. A distinct maximum should be visible in the curve.

*) in "TOCCSL_main.m"
	Several plots before/after photobleaching, during and at the end of the recovery time can be shown. This can be useful to get a rough estimate on certain parameters like t_bleach, t_rec. 

********** SIMULATION OUTPUT **********

The main results including information about the oligomeric state, fluorescent state, colocalizations (FP/false positives) are contained in several arrays (results.WS_simple, results.FP_count, results.WS_wo_FP, results.WS_FP_detail) which can be analyzed with  "data_analysis_bootstrapping.m".

Using the loop script the results of all (typically 1000) runs of the main simulation for a specific parameter set are stored in the in one file in the array "all_results" together with the simulation parameters. Hence, the simulation results for each value of the varied parameter in the loop will be stored in an individual file.

********** DATA ANALYSIS **********

For analysis of looped simulation runs following file can be used:
 "data_analysis_bootstrapping.m".

Infos on data structure etc. can be found in the paper.