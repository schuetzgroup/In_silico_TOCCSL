clearvars
close all hidden

%% read in all data files
allfiles=dir('*.txt');
filenames=string(zeros(1,length(allfiles)-4));

for i=1:(length(allfiles))
    filenames(i)= allfiles(i).name;
end

%% insert values for photobleaching intensity & choose first and last frame to be analyzed
intensity=5.32;
start=3;
ende=203; % plot up

for j=1:length(filenames)
    file=char(filenames(j));
    data=dlmread(file);
    x=data((start:ende),1);
    x=x-min(x);
    y=data((start:ende),2);
    y=y-min(y); % subtract offset from last data point
    y=y/y(1); % normalize to 1 for first data point
    % store all experimental data used for fit
    x_all(j,:) = x;
    y_all(j,:) = y;
    [results{j},gof] = multiexponential_fit(x,y);
end

%% determine photobleaching parameters

for k=1:length(results)
    
    alpha(k)=results{k}.alpha;
    beta(k)=results{k}.beta;
    A(k)=results{k}.A;
    B(k)=results{k}.B;
end

alpha
mean_alpha=mean(alpha)
beta
mean_beta=mean(beta)
A=mean(A)
B=mean(B)
A_normalized=A/(A+B)
B_normalized=1-A_normalized

%% plot all data normalized to 1 together with mean fit

% fit curve
x_fit = 0:1:size(x_all,2)-1; % in 1ms steps
y_fit = A_normalized*exp(-mean_alpha*x_fit) + B_normalized*exp(-mean_beta*x_fit);
y_fit_A = A_normalized*exp(-mean_alpha*x_fit);
y_fit_B = B_normalized*exp(-mean_beta*x_fit);

figure()
hold on

% experimental data
for i=1:length(filenames)
    plot(x_all(i,:),y_all(i,:),'-.','Color',[0 0.4470 0.7410])
end
% fit curve
plot(x_fit, y_fit, '-k','LineWidth',2)
plot(x_fit, y_fit_A, '--','LineWidth',1.5,'Color',[0.8500 0.3250 0.0980])
plot(x_fit, y_fit_B, '--','LineWidth',1.5,'Color',[0.9290 0.6940 0.1250])

box on
xlabel('Cumulative illumination time / ms')
ylabel('Normalized background-corrected fluorescence intensity')
legend('Experimental data (cell 1)','Experimental data (cell 2)','Experimental data (cell 3)','Experimental data (cell 4)','Experimental data (cell 5)','Experimental data (cell 6)','Experimental data (cell 7)','Experimental data (cell 8)','Bi-exponential fit','Population A', 'Population B')
ylim([0 1])
title('Photobleaching curve')
savefig(strcat('photobleaching_curve.fig'))