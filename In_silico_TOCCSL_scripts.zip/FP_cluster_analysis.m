function [A,WS_simple,WS_wo_FP,WS_FP_detail,FP_count]=FP_cluster_analysis(Traj,par)
% WS_simple: array with all molecules inside analysis ROI including clusters
% --> in case no cluster analysis is needed/wanted

%% ACCOUNT FOR RESOLUTION LIMIT & FALSE POSITIVES
% if particles are not separated by more than par.fp_limit, they are
% considered as an aggregate (cluster size can be arbitrary!)
 
% create array A with data points of last image (after recovery time)
% circular analysis ROI    
analysis_mask = (abs(Traj(end,:,1)-par.gridsize/2).^2+abs(Traj(end,:,2)-par.gridsize/2).^2)...  
    <= (par.roi_crit_x/2 + par.fp_limit).^2 & Traj(end,:,4)>0;

A=NaN(sum(analysis_mask),size(Traj,3)+1);
A(:,1:(end-1))=Traj(end,analysis_mask,:);

%% determine particles inside th analysis ROI (without resolution limited ring)
check_in = (abs(A(:,1)-par.gridsize/2)).^2 + (abs(A(:,2)-par.gridsize/2)).^2 <= (par.roi_crit_x/2).^2;
A_in = A(check_in,1:4); % no need for cluster information (5th entry in 2nd dimension)

%% determination of false positive clusters inside analysis roi
cluster_no=0; % initialization

% check distance between molecules
for ii=1:size(A_in,1)
    % masks for particles with distance thresholds
    distance_fp = sqrt((A_in(ii,1)-A(:,1)).^2 + (A_in(ii,2)-A(:,2)).^2);    
    check_fp = distance_fp < par.fp_limit;
    
    if sum(check_fp)>1
        %check if other particles are part of already determined cluster
        if any(A(check_fp,5)>0)
            A(check_fp,5) = min(A(check_fp,5)); % take minimum of already existing cluster number
        % else define new cluster  
        else 
            cluster_no = cluster_no + 1;
            A(check_fp,5) = cluster_no;
        end
    else % if no FP
        A(check_fp,5)=0;
    end
end

% get rid of molecules in A that are outside analysis ROI and not part of
% FP cluster
mask_pass = check_in | A(:,5)>0;
A_new = A(mask_pass,:);
A = A_new;

%% "Waehlerstrom" analysis (which n-mer state + which oligomeric state?)
% WS_simple: array with ALL molecules inside analysis ROI withouth counting
% any clusters
% --> in case no cluster analysis is needed/wanted

WS_simple = NaN(par.n_nmer, par.n_nmer);
for nmer=1:par.n_nmer
    for nfl=1:par.n_nmer
        WS_simple(nmer,nfl) = sum(A_in(:,3)==nmer & A_in(:,4)==nfl);
    end
end

% WS_wo_FP: WS array without molecules, which are part of an FP cluster
WS_wo_FP = NaN(par.n_nmer, par.n_nmer);
for nmer=1:par.n_nmer
    for nfl=1:par.n_nmer
        WS_wo_FP(nmer,nfl) = sum(A(:,3)==nmer & A(:,4)==nfl & A(:,5)==0);
    end
end

% "Waehlerstrom" in detail for FP clusters
% Create Array WS for subunit analysis
% Dimension1 i: real i-mer-Fraction (Number of Fluorophores)
% Dimension2 j: experimentally appearing cluster size with j visible fluorophores

max_fp_size = 5*par.n_nmer; % "semi-hard coded" value for maximum cluster size
% cluster_WS=zeros(max_fp_size,par.n_nmer); % dim1: cluster_size, dim2: real oligomeric state of contributing molecules
WS_FP_detail = zeros(max_fp_size,par.n_nmer,par.n_nmer); % dim1: cluster_size, dim2: real oligomeric state of contributing molecules dim3: fluorescent state

% highest cluster number for determination of loop sizes in the next lines
max_clusternum = max(A(:,5));

if max_clusternum~=0
    fp_size = NaN(1,max_clusternum); % init
    % determine size of clusters for each cluster number in 5th entry of array A
    for cl=1:max_clusternum
        fp_size(cl) = sum(A(A(:,5)==cl,4)); % number of active fluorophores in cluster
        if fp_size(cl)>0 & fp_size(cl)<=max_fp_size
            check_CA = A(:,5)==cl; % select particles of the investigated cluster
            for tt=1:par.n_nmer
                for uu=1:par.n_nmer
                    WS_FP_detail(fp_size(cl),tt,uu) = WS_FP_detail(fp_size(cl),tt,uu) + sum(A(check_CA,3)==tt & A(check_CA,4)==uu);
                end
            end
        end
    end
    % how many FP clusters in each fraction
    FP_count = zeros(1,max_fp_size);
    for ii=1:max_fp_size
        %FP_count
        %fp_size
        %max_fp_size
        FP_count(ii)=sum(fp_size==ii); % contains the number of FP clusters in one line
    end  
else
    FP_count = zeros(1,max_fp_size);
end