clearvars
close all

tic

%% working directory 
datetoday = datestr(datetime('now','Format','yyyy-MM-dd'),'yyyymmdd');
workingdir=strcat(datetoday,'_DATA_recovery_diffraction_dens100');
mkdir(workingdir);

%% range for recovery time and range for main parameter (photobleaching time, diffusion coefficient etc.)
varpar = [0.1:0.2:2.1]; % loop over range of recovery times to determine the optimal recovery time

check.A_figures = 0; % "A_figures" can be stored for debugging if check.A_figures = 1

%% loop for main simulation (variation of recovery time)
for kk=1:length(varpar)  
    
        clear results par Traj run
        close all hidden
        
        %% ASSIGN PARAMETERS
        
        %% simulation structure
        par.n_addruns = 300;                 % number of runs to determine the according analysis region for each recovery time
        par.n_mainruns = 1000;               % number of main runs for each recovery time (for each entry in 'varpar')
        
        %% other parameters 
        par.n_nmer = 2;                      % number of oligomeric fractions
        par.fraction = [0 1];                % relative fractions of n-mers, here: 100% dimers
        %par.fraction = [0.5 0.5];           % relative fractions of n-mers, here: 50% monomers / 50% dimers
        %par.fraction = [0 0 0 1];           % relative fractions of n-mers, here: 100% tetramers
        par.stepno_second = 100;             % simualted time steps per second
        par.density = 100;                   % surface density of molecules per �m�
        par.D = [0.5 0.5];                   % diffusion coefficient D in �m�/s
        par.recovery_time = varpar(kk);      % variation of recovery time
        par.fp_limit = 0.300;                % threshold distance in �m between molecules that are considered as random colocalizations
        par.fp_crit = 0.20;                  % maximum rate of apparent n-mers due to random colocalizations
        par.analysis_method = 'everything';  % all molecules are considered for analysis, including apparent n-mers due to random colocalizations
        par.roi_x = 7;                       % aperture side length in �m
        par.roi_y = 7;                       % aperture side length in �m
        par.d_ap = min(par.roi_x,par.roi_y);
        par.gridsize = 3*par.roi_y;          % side length of cell in multiples of the aperture side length
        
        %% photobleaching parameters 
        par.t_bleach = 4000;                                % photobleaching time in ms
        par.laser_shape = 'diffraction';                    % laser intensity profile: 'diffraction', 'uniform', 'ideal'
        par.sigma_diff = 0.5;                               % sigma for gaussian intensity decay at the aperture edges
        par.edge = 1;                                       % edge region with intensity decay (diffraction-affected laser profile) in �m, which is added to each side of the aperture
        par.bleaching_biex(1) = 0.782;                      % relative fraction A of a biexponential photobleaching curve 
        par.bleaching_biex(2) = 1-par.bleaching_biex(1);    % relative fraction B of a biexponential photobleaching curve
        par.bleaching(1) = 0.2352;                          % mean photobleaching parameter alpha 
        par.bleaching(2) = 0.0297;                          % mean photobleaching parameter beta 

    %% additional simulation runs for each recovery time --> determines analysis ROI size for main simulation
    par.n_preruns = par.n_addruns;
    [par,molnr_bla] = analysis_roi_calculation_fit(par);
    par.molmax_prerun = molnr_bla;

    %% main simulation
    file=matfile(strcat(workingdir,'/sim_results_',datetoday,'_varpar_',num2str(varpar(kk),'%1.1f'),'.mat'),'writable', true);
    
    if check.A_figures
        % directory for A_figures
        % contains data of molecules within analysis region
        adir = strcat('A_figures_',num2str(varpar(kk),'%1.1f'));
        mkdir(adir);
    end
    
    %% repetition of the main simulation
    for run=1:par.n_mainruns
        disp(strcat('Simulation: ',num2str(kk),'/', num2str(length(varpar))))
        run
        par
        [results,Traj,par,A,] = TOCCSL_main(par);
        % store results (kk=t_recovery, oo=run)
        all_results(run) = results;
        
        %% save data for later figures
        if check.A_figures
            fd = matfile(strcat(adir,'/A_',num2str(run),'.mat'),'Writable',true);
            fd.A = A;
        end

        toc
    end
    
    %% store results
    file.results=all_results;
    file.varpar=varpar;

end