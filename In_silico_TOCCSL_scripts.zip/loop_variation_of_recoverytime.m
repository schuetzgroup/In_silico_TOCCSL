clearvars
close all

tic

%% working directory 
datetoday = datestr(datetime('now','Format','yyyy-MM-dd'),'yyyymmdd');
workingdir=strcat(datetoday,'_DATA_recovery_diffraction_dens100');
mkdir(workingdir);

%% range for recovery time and range for main parameter (photobleaching time, diffusion coefficient etc.)
varpar= [0.0333, 0.6:0.6:3.0]; % loop over range for recovery time

check.A_figures = 0;

for kk=1:length(varpar)  % outer loop for main simulation (variation of photobleaching time, diffusion coefficient etc.)
    
    %% Numerical selection of optimal recoverytime 
    % (from 100 simulations) at which most molecules can be 
    % anaylzed without exceeding a false n-mer rate of 20%

        clear results par Traj run
        close all hidden
        
        %% assign parameters
        clear results par Traj run
        close all hidden
        
        %% assign parameters
        par.n_preruns = 100;                % number of simulations for recovery time selection
        par.n_nmer = 2;                     % number of oligomeric fractions
        par.fraction = [0 1];               % 100% dimers
        %par.fraction = [0 0 0 1];          % 100% tetramers
        par.D = [0 0.5];                    % D = 0.5�m�/s (100% dimers)
        %par.D = [0 0 0 0.5];               % D = 0.5�m�/s (100% tetramers)
        par.roi_x = 7;                      % aperture side length = 7�m
        par.roi_y = 7;                      % aperture side length = 7�m 
        par.d_ap = min(par.roi_x,par.roi_y);
        par.density = 100;                  % surface density of molecules
        par.t_bleach = varpar(kk);          % variation of photobleaching time
        par.t_bleach = 4000;                 % photobleaching time = 4s
        par.recovery_time = varpar(kk);     % variation of recovery time
        par.stepno_second = 300;            % simualted time steps per second
        par.sigma_xy = 0;
        par.laser_shape = 'diffraction';    % laser intensity profile: 'diffraction', 'uniform', 'ideal'
        par.fluorophore = 'GFP';            % photobleaching parameters from GFP bleaching curves
        par.intensity = 5.32;               % laser intensity (from experiment)
        par.res_limit = 0.300;              
        par.wavelength = 488;               % laser wavelength (from experiment)
        par.gridsize = 3*par.roi_y;         % side length of cell
        par.fp_limit = 0.300;               % threshold distance between molecules for false n-mer determination
        par.fp_crit = 0.20;                 % maximum false n-mer rate
        par.analysis_method = 'everything'; % all molecules are considered for analysis, including false n-mers
        par.edge = 1;                       % edge region with intensity decay (diffraction-affected laser profile)
        par.sigma_diff=0.5;                 % sigma for half-gaussian intensity decay at the edges
    
    %% additional preruns for only selected recovery time --> determines analysis ROI size for main simulation
    par.n_preruns = 100;
    [par,molnr_bla] = analysis_roi_calculation_fit(par);
    par.molmax_prerun = molnr_bla;

    %% "REAL SIMULATION"
    file=matfile(strcat(workingdir,'/sim_results_',datetoday,'_recovery_diffraction_dens100_',num2str(varpar(kk),'%1.1f'),'.mat'),'writable', true);
    
    % directory for A_figures
    if check.A_figures
        adir = strcat('A_figures_',num2str(varpar(kk),'%1.1f'));
        mkdir(adir);
    end
    
    
    %% repetition of the same simulation
    for run=1:1000
        disp(strcat('Simulation: ',num2str(kk),'/', num2str(length(varpar))))
        run
        par
        [results,Traj,par,A,] = TOCCSL_main(par);
        % store results (kk=t_recovery, oo=run)
        all_results(run) = results;
        
        %% save data for later figures
        if check.A_figures
            fd = matfile(strcat(adir,'/A_',num2str(run),'.mat'),'Writable',true);
            fd.A = A;
        end

        toc
    end
    
    % store results
    file.results=all_results;
    file.varpar=varpar;
    
end