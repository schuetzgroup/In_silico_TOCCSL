function P_bleach = bleaching_probability_diffraction(x_pos,y_pos,biex_frac,par)
%% calculate the bleaching probability for fluorophores
% using formula from Axelrod et al.:
% c = c_0 * exp(- alpha * t_bleach * intensity);
% in double-exponential form.
% Intensity of laser has diffraction profile
% I = 1 in the center region
% I = Gaussian shaped in edge zone

% diffraction in x-direction
if x_pos <= par.roi_x/2 % if inside inner zone
    Z1 = 1;
elseif x_pos > par.roi_x/2% if inside "edge" zone
    Z1 = exp(-(x_pos-(par.roi_x/2))^2/par.sigma_diff^2);
end
% diffraction in y-direction
if y_pos <= par.roi_y/2 % if inside inner zone
    Z2 = 1;
elseif y_pos > par.roi_y/2 % if inside "edge" zone
    Z2 = exp(-(y_pos-(par.roi_y/2))^2/par.sigma_diff^2);
end

% calculate laser intensity in x and y direction
Z=Z1*Z2;

P_bleach = 1 - exp(-Z*par.bleaching(biex_frac)*par.delta_t*1000);