function P_bleach = bleaching_probability_diffraction(x_pos,y_pos,time_inside,par)
% calculate the bleaching probability for fluorophores
% using formula from Axelrod et al.:
% c = c_0 * exp(- alpha * t_bleach * intensity);
% in double-exponential form.
% Intensity of Laser has diffraction profile
% I=1 in the center region
% I = Gaussian shaped in edge zone

for posi = 1:length(x_pos)
    if x_pos(posi) <= par.roi_x/2 % inner region
        Z1 = 1;
    elseif x_pos(posi) > par.roi_x/2 % if inside "edge" region (x_pos/y_pos are already only within illuminated area)
        Z1 = exp(-(x_pos(posi)-(par.roi_x/2))^2/par.sigma_diff^2);
    end
    % diffraction in y-direction
    if y_pos(posi) <= par.roi_y/2 % inner region
        Z2 = 1;
    elseif y_pos(posi) > par.roi_y/2 % "edge" region
        Z2 = exp(-(y_pos(posi)-(par.roi_y/2))^2/par.sigma_diff^2);
    end
    
    %calculate laser intensity in x and y direction
    Z(posi)=Z1*Z2;
    
end
Z_mean = mean(Z);
P_bleach = 1 -(0.782*exp(-par.intensity*Z_mean*par.bleaching(1)*par.delta_t*1000*time_inside)+0.2180*exp(-par.intensity*Z_mean*par.bleaching(2)*par.delta_t*1000*time_inside));