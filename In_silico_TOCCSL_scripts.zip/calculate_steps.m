function [Traj] = calculate_steps(Traj,par)
% CALCULATION OF STEPSIZES
% via separate normally distributed random numbers in x and y direction

stepsize_x = zeros(par.stepno-1,par.partno); % allocation
stepsize_y = zeros(par.stepno-1,par.partno); % allocation

for nmer=1:par.n_nmer
    mask_nmer = Traj(1,:,3)==nmer; % mask for stepsize assignment
    count_nmer = sum(mask_nmer); % number of molecules in n-mer-fraction
    
    x=normrnd(0, sqrt(par.msd(nmer)/2),par.stepno-1,count_nmer);
    y=normrnd(0, sqrt(par.msd(nmer)/2),par.stepno-1,count_nmer);
    
    stepsize_x(:,mask_nmer)=x;
    stepsize_y(:,mask_nmer)=y;
end

% write steps into Traj-array
% later the trajectories are calculated via cumsum-function in main script
Traj(2:end,:,1) = stepsize_x;
Traj(2:end,:,2) = stepsize_y;
    