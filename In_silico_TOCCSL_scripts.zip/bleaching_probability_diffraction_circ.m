function P_bleach = bleaching_probability_diffraction_circ(x_pos,y_pos,biex_frac,par)
%% calculate the bleaching probability for fluorophores
% using formula from Axelrod et al.:
% c = c_0 * exp(- alpha * t_bleach * intensity);
% in double-exponential form.
% Intensity of laser has diffraction profile
% I = 1 in the center region
% I = Gaussian shaped in edge zone

pos_radius = sqrt((x_pos)^2 + (y_pos)^2);
if pos_radius  <= par.roi_x/2 % inner region
    Z = 1;
elseif pos_radius > par.roi_x/2 % if inside "edge" region
    Z = exp(-(pos_radius-(par.roi_x/2))^2/par.sigma_diff^2);
end

% include evaluation of "biex_frac"
P_bleach = 1 - exp(-Z*par.bleaching(biex_frac)*par.delta_t*1000);