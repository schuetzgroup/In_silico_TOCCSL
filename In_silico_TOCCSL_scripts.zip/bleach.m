function Traj=bleach(Traj,par,B)
%% photobleach molecules within the aperture-restricted region
% if bleached --> set fluor. variable to 0.
% adjust bleaching by "par.t_bleach" and "par.bleaching".
% array "B" for single-fluorophore information (multi-exponential population)

switch par.laser_shape
    case 'uniform'
        P_bleach = bleaching_probability_uniform(par,'bleach');
        
        for index_particle=1:par.partno
            % logical arrays for finding out if particles are "inside" the laser
            % beam and how long they have been inside
            check.inside = abs(Traj(1:par.steps_bleach,index_particle,1)-par.gridsize/2) <= par.roi_x/2 ...
                & abs(Traj(1:par.steps_bleach,index_particle,2)-par.gridsize/2) <= par.roi_y/2;

            %calculate p_bleach for whole time inside laser beam
            if any(check.inside)
                for num_fluor=1:Traj(par.steps_bleach,index_particle,4)
                    % distinguish between the bi-exponential populations
                    % via biex_pop
                    time_inside = sum(check.inside);
                    biex_pop = B(index_particle,num_fluor);
                    mc=rand;
                    if mc <= P_bleach(biex_pop,time_inside) % probability dependent on time in laserROI
                        Traj(par.steps_bleach:end,index_particle,4) = Traj(par.steps_bleach:end,index_particle,4)-1;
                    end
                end
            end
        end
        
    case 'diffraction'
        % calculate bleaching probability during time
        % inside the laser beam for each time step
        for time=1:par.steps_bleach      
            mask_inside = abs(Traj(time,:,1)-par.gridsize/2) <= par.roi_x/2 + par.edge...
                & abs(Traj(time,:,2)-par.gridsize/2) <= par.roi_y/2 + par.edge & Traj(time,:,4)>0;
            
            Traj_inside = Traj(time,mask_inside,:);
            B_inside = B(mask_inside,:);
            
            for particle=1:size(Traj_inside,2)
                x_pos = abs(Traj_inside(1,particle,1)-par.gridsize/2);
                y_pos = abs(Traj_inside(1,particle,2)-par.gridsize/2);

                for num_fluor=1:Traj_inside(1,particle,3)
                    if B_inside(particle, num_fluor) > 0
                        biex_frac = B_inside(particle,num_fluor);
                        P_bleach = bleaching_probability_diffraction(x_pos,y_pos,biex_frac,par);
                        mc=rand;
                        if mc <= P_bleach
                            Traj_inside(1,particle,4)=Traj_inside(1,particle,4)-1;
                            B_inside(particle, num_fluor) = 0;
                        end
                    end
                end
            end

            B(mask_inside,:) = B_inside;          
            % write bleached particles in Traj array
            for trans = 1:(size(Traj,1)-time+1)
                Traj(time+trans-1,mask_inside,4)=Traj_inside(1,:,4);
            end
        end
        
    case 'ideal'
        % ideal bleaching of molecules
        % if a molecule is inside the aperture for at least 1 time step, it is
        % instantly photobleached
        
        for index_particle=1:par.partno
            check.inside = abs(Traj(1:par.steps_bleach,index_particle,1)-par.gridsize/2) <= par.roi_x/2 ...
                & abs(Traj(1:par.steps_bleach,index_particle,2)-par.gridsize/2) <= par.roi_y/2;
            check.inside_time = cumsum(double(check.inside));
            if any(check.inside)
                Traj(par.steps_bleach:end,index_particle,4) = 0;
            end
        end
end