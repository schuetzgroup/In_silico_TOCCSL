function Traj=bleach(Traj,par)
% "bleach" particles within the aperture-restricted region
% if bleached --> set fluor. variable to 0)
% adjust bleaching by "par.t_bleach" and "par.bleaching"

switch par.laser_shape
    case 'uniform'
        P_bleach = bleaching_probability_uniform(par,'bleach');
        
        for index_particle=1:par.partno
            % logical arrays for finding out if particles are "inside" the laser
            % beam and how long they have been in the illuminated area
            check.inside = abs(Traj(1:par.steps_bleach,index_particle,1)-par.gridsize/2) <= par.roi_x/2 ...
                & abs(Traj(1:par.steps_bleach,index_particle,2)-par.gridsize/2) <= par.roi_y/2;
            
            %calculate p_bleach for whole time inside laser beam
            if any(check.inside)
                for num_fluor=1:Traj(par.steps_bleach,index_particle,4)
                    mc=rand;
                    if mc <= P_bleach(sum(check.inside)) % probability dependent on time in laserROI
                        Traj(par.steps_bleach:end,index_particle,4) = Traj(par.steps_bleach:end,index_particle,4)-1;
                    end
                end
            end
        end
        
    case 'diffraction'
        % calculate bleaching probability according mean intensity
        % during time inside the laser beam for each time step individually
        
        for index_particle=1:par.partno
            check.inside = abs(Traj(1:par.steps_bleach,index_particle,1)-par.gridsize/2) <= par.roi_x/2+par.edge ...
                & abs(Traj(1:par.steps_bleach,index_particle,2)-par.gridsize/2) <= par.roi_y/2+par.edge;
            time_inside = sum(check.inside);
            
            if time_inside ~= 0
                Traj_inside = Traj(1:par.steps_bleach,index_particle,1:2);
                x_pos = abs(Traj_inside(check.inside,1,1)-par.gridsize/2);
                y_pos = abs(Traj_inside(check.inside,1,2)-par.gridsize/2);
                
                P_bleach = bleaching_probability_diffraction(x_pos,y_pos,time_inside,par);
                
                for num_fluor=1:Traj(1,index_particle,4)
                    mc=rand;
                    if mc <= P_bleach
                        Traj(par.steps_bleach:end,index_particle,4) = Traj(par.steps_bleach:end,index_particle,4)-1;
                    end
                end
            end
            
        end     
        
    case 'ideal'
        % ideal bleaching of molecules
        % if molecule is inside the aperture for at least 1 time step, it is
        % instantly photobleached
        
        for index_particle=1:par.partno
            check.inside = abs(Traj(1:par.steps_bleach,index_particle,1)-par.gridsize/2) <= par.roi_x/2 ...
                & abs(Traj(1:par.steps_bleach,index_particle,2)-par.gridsize/2) <= par.roi_y/2;
            check.inside_time = cumsum(double(check.inside));         
            if any(check.inside)
                Traj(par.steps_bleach:end,index_particle,4) = 0;
            end
        end        
end