clearvars
close all

%% HARD-CODED parameters, could otherwise be read out of results file

% maximum number of oligomeric subunits
nmer_max = 2; 
% nmer_max = 4; % for tetramers

% maximum number of oligomeric subunits for FP
nmer_max_FP = 5*nmer_max; % 5 times the maximum of subunits, e.g. 10 for dimers, 20 for tetramers

files=dir('*.mat');

fractions_FP_total = zeros(length(files),nmer_max_FP);
FP_total = NaN(length(files),nmer_max_FP);
WS_wo_FP_total_allruns = NaN(length(files),nmer_max);
% FP_counts = zeros(length(files),size(results,2),10);
FP_counts = zeros(length(files),1000,nmer_max_FP);
WS_wo_FP = zeros(length(files),1000,nmer_max,nmer_max);

for run=1:length(files)
    
    load(files(run).name);
    
    %% read in results
    par = results.parameters;
    
    %% whole analysis region
    size_ws1=0;
    size_ws2=0;
    
    for xy=1:size(results,2)
        size_ws1 = max(size_ws1,size(results(xy).WS_wo_FP,1));
        size_ws2 = max(size_ws2,size(results(xy).WS_wo_FP,2));
    end
    
    for xx=1:size(results,2)
        WS_wo_FP(run,xx,1:size(results(xx).WS_wo_FP,1),1:size(results(xx).WS_wo_FP,2)) = results(xx).WS_wo_FP;
    end
    
    %% sum over first two dimensions to get total number of molecules
    WS_wo_FP_runsum = squeeze(sum(squeeze(WS_wo_FP(run,:,:,:)),1));
    WS_wo_FP_total = sum(WS_wo_FP_runsum,1);
    
    %% read in false n-mer counts
    for xx=1:size(results,2)
        FP_counts(run,xx,:) = results(xx).FP_count;
    end
    
    FP_total(run,:) = sum(squeeze(FP_counts(run,:,:)),1);
    
    %% add up fractions from WS_wo_FP and FP_count to get total number of molecules incl. false n-mers
    for i=1:length(WS_wo_FP_total)
        FP_total(run,i) = FP_total(run,i) + WS_wo_FP_total(i);
    end
    
    Total_total(run) = sum(FP_total(run,:),2);
    fractions_FP_total(run,:) = FP_total(run,:)./Total_total(run);
    WS_wo_FP_total_allruns(run,:)= WS_wo_FP_total;
    Total_total_wo_FP(run) = sum(WS_wo_FP_total_allruns(run,:));
    %WS_fracs(run,:,:) = WS_total(run,:,:)./Total_total(run);
    %fractions_total(run,:) = sum(WS_fracs(run,:,:),2);
end   

%% write mat-file with plot data
%mfile = matfile('C:\Users\Bomberwoman-PC\Documents\Clara\bootstrapping_analysis.mat','Writable',true);
mfile.fractions = fractions_FP_total;
mfile.varpar = varpar;
mfile.datapoints = Total_total;
mfile.parameter = par;
% varpar = [250 300 400 500 1000 2000 4000 10000]; 


%% BOOTSTRAPPING (STANDARD/EFRON)

%% 1) BOOTSTRAPPING for NUMBER of MOLECULES

molecules_bt_fun = @(x)sum(x);
N_samples = 10000; % number of samples drawn for a single resampling procedure

%% false n-mers only
molecules_FP_sum = reshape(sum(FP_counts,2), size(FP_counts,1),size(FP_counts,3)); % sum over original 1000 data points

%% number without false n-mers
WS_wo_FP_total_allruns = sum(WS_wo_FP,3); %reshape instead of squeeze
WS_wo_FP_total_allruns = reshape(WS_wo_FP_total_allruns, [size(WS_wo_FP_total_allruns,1)...
    size(WS_wo_FP_total_allruns,2) size(WS_wo_FP_total_allruns,4)]);
molecules_wo_FP_sum = sum(WS_wo_FP_total_allruns,2);
molecules_wo_FP_sum = reshape(molecules_wo_FP_sum, size(molecules_wo_FP_sum,1), size(molecules_wo_FP_sum,3));

%% Total number of molecules incl. false n-mers
molecules_total_allruns = FP_counts(:,:,1:nmer_max_FP);
molecules_total_allruns(:,:,1:size(WS_wo_FP_total_allruns,3)) = molecules_total_allruns(:,:,1:size(WS_wo_FP_total_allruns,3)) + WS_wo_FP_total_allruns(:,:,:);
%Structure: molecules_bt = (Files,Simulation_run(typ. 1000), oligomer incl. FPs);
molecules_total_sum = sum(molecules_total_allruns,2);
molecules_total_sum = reshape(molecules_total_sum, size(molecules_total_allruns,1), size(molecules_total_allruns,3));

for kk=1:length(files)
    for ll=1:nmer_max_FP
        molecules_FP_ci(kk,ll,:) = bootci(N_samples, molecules_bt_fun, (FP_counts(kk,:,ll))');
        molecules_total_ci(kk,ll,:) = bootci(N_samples, molecules_bt_fun, molecules_total_allruns(kk,:,ll)');
    end
    %% without false n-mers, loop only up to nmer_max
    for mm=1:nmer_max
        molecules_wo_FP_ci(kk,mm,:) = bootci(N_samples, molecules_bt_fun ,WS_wo_FP_total_allruns(kk,:,mm)');
    end
end

%% calculate errorbars from confidence interval
eb_FP_low = molecules_FP_sum - molecules_FP_ci(:,:,1);
eb_FP_high = molecules_FP_ci(:,:,2) - molecules_FP_sum;
eb_total_low = molecules_total_sum - molecules_total_ci(:,:,1);
eb_total_high = molecules_total_ci(:,:,2) - molecules_total_sum;
eb_wo_FP_low = molecules_wo_FP_sum - molecules_wo_FP_ci(:,:,1);
eb_wo_FP_high = molecules_wo_FP_ci(:,:,2) - molecules_wo_FP_sum;

%% plot molecule number

%% for dimers

figure()
hold on
% all molecules incl. false n-mers
plot(varpar,sum(molecules_total_sum,2));
% monomers
errorbar(varpar,molecules_total_sum(:,1), eb_total_low(:,1), eb_total_high(:,1));
% dimers
errorbar(varpar,molecules_total_sum(:,2), eb_total_low(:,2), eb_total_high(:,2));
errorbar(varpar,molecules_wo_FP_sum(:,2), eb_wo_FP_low(:,2), eb_wo_FP_high(:,2));
errorbar(varpar,molecules_FP_sum(:,2), eb_FP_low(:,2), eb_FP_high(:,2));
% higher order false n-mers
errorbar(varpar,molecules_total_sum(:,3), eb_total_low(:,3), eb_total_high(:,3));
errorbar(varpar,molecules_total_sum(:,4), eb_total_low(:,4), eb_total_high(:,4));
errorbar(varpar,molecules_total_sum(:,5), eb_total_low(:,5), eb_total_high(:,5));
errorbar(varpar,molecules_total_sum(:,6), eb_total_low(:,6), eb_total_high(:,6));
errorbar(varpar,molecules_total_sum(:,7), eb_total_low(:,7), eb_total_high(:,7));
errorbar(varpar,molecules_total_sum(:,8), eb_total_low(:,8), eb_total_high(:,8));
errorbar(varpar,molecules_total_sum(:,9), eb_total_low(:,9), eb_total_high(:,9));
errorbar(varpar,molecules_total_sum(:,10), eb_total_low(:,10), eb_total_high(:,10));

xlabel('photobleaching time / ms')
% xlabel('recovery time / ms')
% xlabel('diffusion coefficient')
% xlabel('D_2 / D_1')
% xlabel('aperture side length')
% xlabel('side length of cell')
% xlabel('time steps / s^{-1}')
ylabel('apparent n-mers (total number)')
legend('total number of apparent n-mers','apparent monomers','apparent dimers','dimers','false dimers','apparent trimers','apparent tetramers','apparent pentamers','apparent hexamers','apparent heptamers','apparent octamers','apparent enneamers','apparent decamers')
box on
savefig(strcat('total_molecules.fig'))

%% for tetramers (histogram)

% figure()
% hold on
% 
% % % higher order false n-mers
% bar(10,molecules_total_sum(:,10));
% errorbar(10,molecules_total_sum(:,10), eb_total_low(:,10), eb_total_high(:,10));
% bar(9,molecules_total_sum(:,9));
% errorbar(9,molecules_total_sum(:,9), eb_total_low(:,9), eb_total_high(:,9));
% bar(8,molecules_total_sum(:,8));
% errorbar(8,molecules_total_sum(:,8), eb_total_low(:,8), eb_total_high(:,8));
% bar(7,molecules_total_sum(:,7));
% errorbar(7,molecules_total_sum(:,7), eb_total_low(:,7), eb_total_high(:,7));
% bar(6,molecules_total_sum(:,6));
% errorbar(6,molecules_total_sum(:,6), eb_total_low(:,6), eb_total_high(:,6));
% bar(5,molecules_total_sum(:,5));
% errorbar(5,molecules_total_sum(:,5), eb_total_low(:,5), eb_total_high(:,5));
% 
% % % tetramers
% bar(4,molecules_total_sum(:,4));
% errorbar(4,molecules_total_sum(:,4), eb_total_low(:,4), eb_total_high(:,4));
% bar(4,molecules_wo_FP_sum(:,4));
% errorbar(4,molecules_wo_FP_sum(:,4), eb_wo_FP_low(:,4), eb_wo_FP_high(:,4));
% bar(4,molecules_FP_sum(:,4));
% errorbar(4,molecules_FP_sum(:,4), eb_FP_low(:,4), eb_FP_high(:,4));
% 
% % % trimers
% bar(3,molecules_total_sum(:,3));
% errorbar(3,molecules_total_sum(:,3), eb_total_low(:,3), eb_total_high(:,3));
% bar(3,molecules_wo_FP_sum(:,3));
% errorbar(3,molecules_wo_FP_sum(:,3), eb_wo_FP_low(:,3), eb_wo_FP_high(:,3));
% bar(3,molecules_FP_sum(:,3));
% errorbar(3,molecules_FP_sum(:,3), eb_FP_low(:,3), eb_FP_high(:,3));
% 
% % % dimers
% bar(2,molecules_total_sum(:,2));
% errorbar(2,molecules_total_sum(:,2), eb_total_low(:,2), eb_total_high(:,2));
% bar(2,molecules_wo_FP_sum(:,2));
% errorbar(2,molecules_wo_FP_sum(:,2), eb_wo_FP_low(:,2), eb_wo_FP_high(:,2));
% bar(2,molecules_FP_sum(:,2));
% errorbar(2,molecules_FP_sum(:,2), eb_FP_low(:,2), eb_FP_high(:,2));
% 
% % % monomers
% bar(1,molecules_total_sum(:,1));
% errorbar(1,molecules_total_sum(:,1), eb_total_low(:,1), eb_total_high(:,1));
% 
% xlabel('')
% legend('apparent decamers','','apparent enneamers','','apparent octamers','','apparent heptamers','','apparent hexamers','','apparent pentamers','','apparent tetramers','','tetramers','','false tetramers','','apparent trimers','','trimers','','false trimers','','apparent dimers','','dimers','','false dimers','','apparent monomers')
% savefig(strcat('total_molecules.fig'))

%% for tetramers (plot)

% figure()
% hold on
% % all molecules incl. false n-mers
% plot(varpar,sum(molecules_total_sum,2));
% % monomers
% errorbar(varpar,molecules_total_sum(:,1), eb_total_low(:,1), eb_total_high(:,1));
% % dimers
% errorbar(varpar,molecules_total_sum(:,2), eb_total_low(:,2), eb_total_high(:,2));
% % trimers
% errorbar(varpar,molecules_total_sum(:,3), eb_total_low(:,3), eb_total_high(:,3));
% % tetramers
% errorbar(varpar,molecules_total_sum(:,4), eb_total_low(:,4), eb_total_high(:,4));
% errorbar(varpar,molecules_wo_FP_sum(:,4), eb_wo_FP_low(:,4), eb_wo_FP_high(:,4));
% errorbar(varpar,molecules_FP_sum(:,4), eb_FP_low(:,4), eb_FP_high(:,4));
% 
% % higher order false n-mers
% errorbar(varpar,molecules_total_sum(:,5), eb_total_low(:,5), eb_total_high(:,5));
% errorbar(varpar,molecules_total_sum(:,6), eb_total_low(:,6), eb_total_high(:,6));
% errorbar(varpar,molecules_total_sum(:,7), eb_total_low(:,7), eb_total_high(:,7));
% errorbar(varpar,molecules_total_sum(:,8), eb_total_low(:,8), eb_total_high(:,8));
% errorbar(varpar,molecules_total_sum(:,9), eb_total_low(:,9), eb_total_high(:,9));
% errorbar(varpar,molecules_total_sum(:,10), eb_total_low(:,10), eb_total_high(:,10));
% 
% xlabel('recovery time / ms')
% % xlabel('recovery time / ms')
% % xlabel('diffusion coefficient')
% % xlabel('D_2 / D_1')
% % xlabel('aperture side length')
% % xlabel('side length of cell')
% % xlabel('time steps / s^{-1}')
% ylabel('apparent n-mers (total number)')
% legend('total number of apparent n-mers','apparent monomers','apparent dimers','apparent trimers','apparent tetramers','tetramers','false tetramers','apparent pentamers','apparent hexamers','apparent heptamers','apparent octamers','apparent enneamers','apparent decamers')
% box on
% savefig(strcat('total_molecules.fig'))

%% 2) BOOTSTRAPPING for FRACTIONS

%% mean fractions
total_oligo = sum(molecules_total_sum,2);
frac_FP_mean = 100*molecules_FP_sum./total_oligo;
frac_total_mean = 100*molecules_total_sum./total_oligo;
frac_wo_FP_mean = 100*molecules_wo_FP_sum./total_oligo;

%% for dimers

fracs_bt_fun_FP = @(x,y1,y2,y3,y4,y5,y6,y7,y8,y9,y10)100*sum(x)/(sum(y1)+sum(y2)+sum(y3)+sum(y4)+sum(y5)+sum(y6)+sum(y7)+sum(y8)+sum(y9)+sum(y10));

for kk=1:length(files)
    for ll=1:nmer_max_FP
        %% false n-mers only
        frac_FP_ci(kk,ll,:) = bootci(N_samples, {fracs_bt_fun_FP, FP_counts(kk,:,ll)',...
            molecules_total_allruns(kk,:,1)',molecules_total_allruns(kk,:,2)',molecules_total_allruns(kk,:,3)',...
            molecules_total_allruns(kk,:,4)',molecules_total_allruns(kk,:,5)',molecules_total_allruns(kk,:,6)',...
            molecules_total_allruns(kk,:,7)',molecules_total_allruns(kk,:,8)',molecules_total_allruns(kk,:,9)',...
            molecules_total_allruns(kk,:,10)'});

        %% Total number of molecules incl. false n-mers
            frac_total_ci(kk,ll,:) = bootci(N_samples, {fracs_bt_fun_FP, molecules_total_allruns(kk,:,ll)',...
            molecules_total_allruns(kk,:,1)',molecules_total_allruns(kk,:,2)',molecules_total_allruns(kk,:,3)',...
            molecules_total_allruns(kk,:,4)',molecules_total_allruns(kk,:,5)',molecules_total_allruns(kk,:,6)',...
            molecules_total_allruns(kk,:,7)',molecules_total_allruns(kk,:,8)',molecules_total_allruns(kk,:,9)',...
            molecules_total_allruns(kk,:,10)'});
    end

    for mm=1:nmer_max
        %% number without false n-mers
        frac_wo_FP_ci(kk,mm,:) = bootci(N_samples, {fracs_bt_fun_FP, WS_wo_FP_total_allruns(kk,:,mm)',...
            molecules_total_allruns(kk,:,1)',molecules_total_allruns(kk,:,2)',molecules_total_allruns(kk,:,3)',...
            molecules_total_allruns(kk,:,4)',molecules_total_allruns(kk,:,5)',molecules_total_allruns(kk,:,6)',...
            molecules_total_allruns(kk,:,7)',molecules_total_allruns(kk,:,8)',molecules_total_allruns(kk,:,9)',...
            molecules_total_allruns(kk,:,10)'});
    end
end

%% for tetramers

% fracs_bt_fun_FP = @(x,y1,y2,y3,y4,y5,y6,y7,y8,y9,y10,y11,y12,y13,y14,y15,y16,y17,y18,y19,y20)100*sum(x)/(sum(y1)+sum(y2)+sum(y3)+sum(y4)+sum(y5)+sum(y6)+sum(y7)+sum(y8)+sum(y9)+sum(y10)+sum(y11)+sum(y12)+sum(y13)+sum(y14)+sum(y15)+sum(y16)+sum(y17)+sum(y18)+sum(y19)+sum(y20));
% % fracs_bt_fun_wo_FP = @(x,y1,y2)100*sum(x)/(sum(y1)+sum(y2));
% 
% for kk=1:length(files)
%     for ll=1:nmer_max_FP
%         frac_FP_ci(kk,ll,:) = bootci(N_samples, {fracs_bt_fun_FP, FP_counts(kk,:,ll)',...
%             molecules_total_allruns(kk,:,1)',molecules_total_allruns(kk,:,2)',molecules_total_allruns(kk,:,3)',...
%             molecules_total_allruns(kk,:,4)',molecules_total_allruns(kk,:,5)',molecules_total_allruns(kk,:,6)',...
%             molecules_total_allruns(kk,:,7)',molecules_total_allruns(kk,:,8)',molecules_total_allruns(kk,:,9)',...
%             molecules_total_allruns(kk,:,10)',molecules_total_allruns(kk,:,11)',molecules_total_allruns(kk,:,12)',...
%             molecules_total_allruns(kk,:,13)',molecules_total_allruns(kk,:,14)',molecules_total_allruns(kk,:,15)',...
%             molecules_total_allruns(kk,:,16)',molecules_total_allruns(kk,:,17)',molecules_total_allruns(kk,:,18)',...
%             molecules_total_allruns(kk,:,19)',molecules_total_allruns(kk,:,20)'});
% 
%         frac_total_ci(kk,ll,:) = bootci(N_samples, {fracs_bt_fun_FP, molecules_total_allruns(kk,:,ll)',...
%             molecules_total_allruns(kk,:,1)',molecules_total_allruns(kk,:,2)',molecules_total_allruns(kk,:,3)',...
%             molecules_total_allruns(kk,:,4)',molecules_total_allruns(kk,:,5)',molecules_total_allruns(kk,:,6)',...
%             molecules_total_allruns(kk,:,7)',molecules_total_allruns(kk,:,8)',molecules_total_allruns(kk,:,9)',...
%             molecules_total_allruns(kk,:,10)',molecules_total_allruns(kk,:,11)',molecules_total_allruns(kk,:,12)',...
%             molecules_total_allruns(kk,:,13)',molecules_total_allruns(kk,:,14)',molecules_total_allruns(kk,:,15)',...
%             molecules_total_allruns(kk,:,16)',molecules_total_allruns(kk,:,17)',molecules_total_allruns(kk,:,18)',...
%             molecules_total_allruns(kk,:,19)',molecules_total_allruns(kk,:,20)'});
%     end
% 
%     for mm=1:nmer_max
%         frac_wo_FP_ci(kk,mm,:) = bootci(N_samples, {fracs_bt_fun_FP, WS_wo_FP_total_allruns(kk,:,mm)',...
%             molecules_total_allruns(kk,:,1)',molecules_total_allruns(kk,:,2)',molecules_total_allruns(kk,:,3)',...
%             molecules_total_allruns(kk,:,4)',molecules_total_allruns(kk,:,5)',molecules_total_allruns(kk,:,6)',...
%             molecules_total_allruns(kk,:,7)',molecules_total_allruns(kk,:,8)',molecules_total_allruns(kk,:,9)',...
%             molecules_total_allruns(kk,:,10)',molecules_total_allruns(kk,:,11)',molecules_total_allruns(kk,:,12)',...
%             molecules_total_allruns(kk,:,13)',molecules_total_allruns(kk,:,14)',molecules_total_allruns(kk,:,15)',...
%             molecules_total_allruns(kk,:,16)',molecules_total_allruns(kk,:,17)',molecules_total_allruns(kk,:,18)',...
%             molecules_total_allruns(kk,:,19)',molecules_total_allruns(kk,:,20)'});
%     end
% end

%% calculate errorbars from confidence interval
eb_frac_FP_low = frac_FP_mean - frac_FP_ci(:,:,1);
eb_frac_FP_high = frac_FP_ci(:,:,2) - frac_FP_mean;
eb_frac_total_low = frac_total_mean - frac_total_ci(:,:,1);
eb_frac_total_high = frac_total_ci(:,:,2) - frac_total_mean;
eb_frac_wo_FP_low = frac_wo_FP_mean - frac_wo_FP_ci(:,:,1);
eb_frac_wo_FP_high = frac_wo_FP_ci(:,:,2) - frac_wo_FP_mean;

%% plot n-mer fractions

%% for dimers

figure()
hold on
% monomers
errorbar(varpar,frac_total_mean(:,1), eb_frac_total_low(:,1), eb_frac_total_high(:,1));
% dimers
errorbar(varpar,frac_total_mean(:,2), eb_frac_total_low(:,2), eb_frac_total_high(:,2));
errorbar(varpar,frac_wo_FP_mean(:,2), eb_frac_wo_FP_low(:,2), eb_frac_wo_FP_high(:,2));
errorbar(varpar,frac_FP_mean(:,2), eb_frac_FP_low(:,2), eb_frac_FP_high(:,2));
% higher order false n-mers
errorbar(varpar,frac_FP_mean(:,3), eb_frac_FP_low(:,3), eb_frac_FP_high(:,3));
errorbar(varpar,frac_FP_mean(:,4), eb_frac_FP_low(:,4), eb_frac_FP_high(:,4));
errorbar(varpar,frac_FP_mean(:,5), eb_frac_FP_low(:,5), eb_frac_FP_high(:,5));
errorbar(varpar,frac_FP_mean(:,6), eb_frac_FP_low(:,6), eb_frac_FP_high(:,6));
errorbar(varpar,frac_FP_mean(:,7), eb_frac_FP_low(:,7), eb_frac_FP_high(:,7));
errorbar(varpar,frac_FP_mean(:,8), eb_frac_FP_low(:,8), eb_frac_FP_high(:,8));
errorbar(varpar,frac_FP_mean(:,9), eb_frac_FP_low(:,9), eb_frac_FP_high(:,9));
errorbar(varpar,frac_FP_mean(:,10), eb_frac_FP_low(:,10), eb_frac_FP_high(:,10));

ylim([0 100])
xlabel('photobleaching time / ms') 
% xlabel('recovery time / ms')
% xlabel('diffusion coefficient')
% xlabel('D_2 / D_1')
% xlabel('aperture side length')
% xlabel('side length of cell')
% xlabel('time steps / s^{-1}')
ylabel('apparent n-mers / %')
legend('apparent monomers','apparent dimers','dimers','false dimers','apparent trimers','apparent tetramers','apparent pentamers','apparent hexamers','apparent heptamers','apparent octamers','apparent enneamers','apparent decamers')
box on
savefig(strcat('fractions_nmers.fig'))

%% for tetramers (histogram)

% figure()
% hold on
% 
% % % higher order false n-mers
% bar(10,frac_total_mean(:,10));
% errorbar(10,frac_total_mean(:,10), eb_frac_total_low(:,10), eb_frac_total_high(:,10));
% bar(9,frac_total_mean(:,9));
% errorbar(9,frac_total_mean(:,9), eb_frac_total_low(:,9), eb_frac_total_high(:,9));
% bar(8,frac_total_mean(:,8));
% errorbar(8,frac_total_mean(:,8), eb_frac_total_low(:,8), eb_frac_total_high(:,8));
% bar(7,frac_total_mean(:,7));
% errorbar(7,frac_total_mean(:,7), eb_frac_total_low(:,7), eb_frac_total_high(:,7));
% bar(6,frac_total_mean(:,6));
% errorbar(6,frac_total_mean(:,6), eb_frac_total_low(:,6), eb_frac_total_high(:,6));
% bar(5,frac_total_mean(:,5));
% errorbar(5,frac_total_mean(:,5), eb_frac_total_low(:,5), eb_frac_total_high(:,5));
% 
% % % tetramers
% bar(4,frac_total_mean(:,4));
% errorbar(4,frac_total_mean(:,4), eb_frac_total_low(:,4), eb_frac_total_high(:,4));
% bar(4,frac_wo_FP_mean(:,4));
% errorbar(4,frac_wo_FP_mean(:,4), eb_frac_wo_FP_low(:,4), eb_frac_wo_FP_high(:,4));
% bar(4,frac_FP_mean(:,4));
% errorbar(4,frac_FP_mean(:,4), eb_frac_FP_low(:,4), eb_frac_FP_high(:,4));
% 
% % % trimers
% bar(3,frac_total_mean(:,3));
% errorbar(3,frac_total_mean(:,3), eb_frac_total_low(:,3), eb_frac_total_high(:,3));
% bar(3,frac_wo_FP_mean(:,3));
% errorbar(3,frac_wo_FP_mean(:,3), eb_frac_wo_FP_low(:,3), eb_frac_wo_FP_high(:,3));
% bar(3,frac_FP_mean(:,3));
% errorbar(3,frac_FP_mean(:,3), eb_frac_FP_low(:,3), eb_frac_FP_high(:,3));
% 
% % % dimers
% bar(2,frac_total_mean(:,2));
% errorbar(2,frac_total_mean(:,2), eb_frac_total_low(:,2), eb_frac_total_high(:,2));
% bar(2,frac_wo_FP_mean(:,2));
% errorbar(4,frac_wo_FP_mean(:,2), eb_frac_wo_FP_low(:,2), eb_frac_wo_FP_high(:,2));
% bar(2,frac_FP_mean(:,2));
% errorbar(4,frac_FP_mean(:,2), eb_frac_FP_low(:,2), eb_frac_FP_high(:,2));
% 
% % % monomers
% bar(1,frac_total_mean(:,1));
% errorbar(1,frac_total_mean(:,1), eb_frac_total_low(:,1), eb_frac_total_high(:,1));
% 
% xlabel('')
% legend('apparent decamers','','apparent enneamers','','apparent octamers','','apparent heptamers','','apparent hexamers','','apparent pentamers','','apparent tetramers','','tetramers','','false tetramers','','apparent trimers','','trimers','','false trimers','','apparent dimers','','dimers','','false dimers','','apparent monomers')
% savefig(strcat('fractions_nmers.fig'))

%% for tetramers (plot)

% figure()
% hold on
% % monomers
% errorbar(varpar,frac_total_mean(:,1), eb_frac_total_low(:,1), eb_frac_total_high(:,1));
% % dimers
% errorbar(varpar,frac_total_mean(:,2), eb_frac_total_low(:,2), eb_frac_total_high(:,2));
% % trimers
% errorbar(varpar,frac_total_mean(:,3), eb_frac_total_low(:,3), eb_frac_total_high(:,3));
% % tetramers
% errorbar(varpar,frac_total_mean(:,4), eb_frac_total_low(:,4), eb_frac_total_high(:,4));
% errorbar(varpar,frac_wo_FP_mean(:,4), eb_frac_wo_FP_low(:,4), eb_frac_wo_FP_high(:,4));
% errorbar(varpar,frac_FP_mean(:,4), eb_frac_FP_low(:,4), eb_frac_FP_high(:,4));
% % higher order false n-mers
% errorbar(varpar,frac_FP_mean(:,5), eb_frac_FP_low(:,5), eb_frac_FP_high(:,5));
% errorbar(varpar,frac_FP_mean(:,6), eb_frac_FP_low(:,6), eb_frac_FP_high(:,6));
% errorbar(varpar,frac_FP_mean(:,7), eb_frac_FP_low(:,7), eb_frac_FP_high(:,7));
% errorbar(varpar,frac_FP_mean(:,8), eb_frac_FP_low(:,8), eb_frac_FP_high(:,8));
% errorbar(varpar,frac_FP_mean(:,9), eb_frac_FP_low(:,9), eb_frac_FP_high(:,9));
% errorbar(varpar,frac_FP_mean(:,10), eb_frac_FP_low(:,10), eb_frac_FP_high(:,10));
% 
% ylim([0 100])
% xlabel('') 
% ylabel('apparent n-mers / %')
% legend('apparent monomers','apparent dimers','apparent trimers','apparent tetramers','tetramers','false tetramers','apparent pentamers','apparent hexamers','apparent heptamers','apparent octamers','apparent enneamers','apparent decamers')
% box on
% savefig(strcat('fractions_nmers.fig'))