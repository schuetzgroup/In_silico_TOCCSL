function Traj=boundary_condition(Traj,par)

%% set molecule to opposite side of the grid when leaving the grid on one side

for index_particle=1:par.partno
    
    X0 = Traj(:,index_particle,1) < 0;
    X1 = Traj(:,index_particle,1) > par.gridsize;
    Y0 = Traj(:,index_particle,2) < 0;
    Y1 = Traj(:,index_particle,2) > par.gridsize;
    
    while any(X0|X1|Y0|Y1)

    Traj(X0,index_particle,1) = Traj(X0,index_particle,1)+par.gridsize;
    Traj(X1,index_particle,1) = Traj(X1,index_particle,1)-par.gridsize;
    Traj(Y0,index_particle,2) = Traj(Y0,index_particle,2)+par.gridsize;
    Traj(Y1,index_particle,2) = Traj(Y1,index_particle,2)-par.gridsize;
    
    X0 = Traj(:,index_particle,1) < 0;
    X1 = Traj(:,index_particle,1) > par.gridsize;  
    Y0 = Traj(:,index_particle,2) < 0;
    Y1 = Traj(:,index_particle,2) > par.gridsize;
    
    end
    
end