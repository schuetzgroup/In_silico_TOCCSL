clearvars
close all

tic

%% working directory 
datetoday = datestr(datetime('now','Format','yyyy-MM-dd'),'yyyymmdd');
workingdir=strcat(datetoday,'_DATA_recovery_diffraction_dens100');
mkdir(workingdir);

%% range for recovery time and range for main parameter (photobleaching time, diffusion coefficient etc.)
var_rec = 0.1:0.3:2.1; % loop over range of recovery times to determine the optimal recovery time
varpar = [250, 300, 400, 500, 1000, 2000, 4000, 10000]; % loop over range of main parameter (photobleaching time, diffusion coefficient etc.)

% debugging
check.sample_runs = 1; % = 1 for normal operation; can be set to higher number for debugging purposes
check.A_figures = 0; % "A_figures" can be stored for debugging if check.A_figures = 1

% allocations
molnr_roi = NaN(1,length(var_rec));
ROI_size_s = NaN(length(var_rec),check.sample_runs);
molnr = NaN(length(var_rec),check.sample_runs);

%% outer loop for main simulation runs
% (variation of photobleaching time, diffusion coefficient etc.)

for kk=1:length(varpar) 
    
    %% inner loop for numerical selection of optimal recoverytime (pre-runs)
    % at which most molecules can be anaylzed without exceeding a random
    % colocalization rate of FP_crit
    
    for ll=1:length(var_rec)
        clear results par Traj run
        close all hidden
        
        %% ASSIGN PARAMETERS
        
        %% simulation structure
        par.n_preruns = 100;                 % number of simulations for each entry in 'var_rec' to determine the optimal recovery time
        par.n_addruns = 300;                 % number of additional runs to determine the according analysis region for the optimal recovery time
        par.n_mainruns = 1000;               % number of main runs for each entry in 'varpar' (the optimal recovery time is determined for each entry of 'varpar')
        
        %% other parameters 
        par.n_nmer = 2;                      % number of oligomeric fractions
        par.fraction = [0 1];                % relative fractions of n-mers, here: 100% dimers
        %par.fraction = [0.5 0.5];           % relative fractions of n-mers, here: 50% monomers / 50% dimers
        %par.fraction = [0 0 0 1];           % relative fractions of n-mers, here: 100% tetramers
        par.stepno_second = 100;             % simualted time steps per second
        %par.stepno_second = varpar(kk);     % variation of simualted time steps per second
        par.density = 100;                   % surface density of molecules per �m�
        %par.density = varpar(kk);           % variation of surface density of molecules
        par.D = [0.5 0.5];                   % diffusion coefficient D in �m�/s
        %par.D = [0 varpar(kk)];             % variation of D (100% dimers)
        %par.D = [0 0 0 varpar(kk)];         % variation of D (100% tetramers)
        %par.D = [0.5 0.5*varpar(kk)];       % variation of D2/D1 (50% monomers / 50% dimers)
        par.recovery_time = var_rec(ll);     % variation of recovery time to find optimal recovery time at which most molecules can be analyzed without exceeding the pre-set rate of random colocalizations
        par.fp_limit = 0.300;                % threshold distance in �m between molecules that are considered as random colocalizations
        par.fp_crit = 0.20;                  % maximum rate of apparent n-mers due to random colocalizations
        par.analysis_method = 'everything';  % all molecules are considered for analysis, including apparent n-mers due to random colocalizations
        par.roi_x = 7;                       % aperture side length in �m
        par.roi_y = 7;                       % aperture side length in �m
        %par.roi_x = varpar(kk);             % variation of aperture side length 
        %par.roi_y = varpar(kk);             % variation of aperture side length 
        par.d_ap = min(par.roi_x,par.roi_y);
        par.gridsize = 3*par.roi_y;          % side length of cell in multiples of the aperture side length
        %par.gridsize = varpar(kk)*par.roi_y;% variation of side length of cell in multiples of the aperture side length
        
        %% photobleaching parameters 
        par.t_bleach = 4000;                                % photobleaching time in ms
        % par.t_bleach = varpar(kk);                        % variation of photobleaching time
        par.laser_shape = 'diffraction';                    % laser intensity profile: 'diffraction', 'uniform', 'ideal'
        par.sigma_diff = 0.5;                               % sigma for gaussian intensity decay at the aperture edges
        par.edge = 1;                                       % edge region with intensity decay (diffraction-affected laser profile) in �m, which is added to each side of the aperture
        par.bleaching_biex(1) = 0.782;                      % relative fraction A of a biexponential photobleaching curve 
        par.bleaching_biex(2) = 1-par.bleaching_biex(1);    % relative fraction B of a biexponential photobleaching curve
        par.bleaching(1) = 0.2352;                          % mean photobleaching parameter alpha 
        par.bleaching(2) = 0.0297;                          % mean photobleaching parameter beta 
        
        for asdf = 1 : check.sample_runs % "check.sample_runs" only for debugging
            % print loop variables
            disp('variable parameter iterator:')
            disp(kk)
            disp('recovery time iterator:')
            disp(ll)
            if check.sample_runs > 1
                disp('check sample run:')
                disp(asdf)
            end
            
            [par,molnr_roi(ll)] = analysis_roi_calculation_fit(par);
            
            %% check ROI size and molecule number for different pre-runs with same parameters
            ROI_size_s(ll,asdf) = par.roi_crit_x;
            molnr(ll,asdf) = molnr_roi(ll);
            
        end
        
        %% plot check of roisize and molecule number
        err_ROI(ll) = 2*std(ROI_size_s(ll,:));
        err_mol(ll) = 2*std(molnr(ll,:));
        
    end
    
    molnr_mean = mean(molnr,2);
    ROI_size = mean(ROI_size_s,2);
    
    %% plot molecule number over recovery time to choose recovery time according to maximum molecule number
    
    % fit curve for choice of recovery time
    [molnr_fit,gof_molnr] = fit_molnr_vs_rectime(var_rec,molnr_mean);
    
    % find maximum in fit (by calculating roots of a polynomial fit)    
    c_fit = coeffvalues(molnr_fit);
    c_der = polyder(c_fit);
    r = roots(c_der);
    if isreal(r)
        r = r(r > min(var_rec) & r < max(var_rec));
        [molmax,molmax_indx] = max(molnr_fit(r));
        recovery_time_molmax = r(molmax_indx);
        par.recovery_time = recovery_time_molmax; % assign optimal recovery time
        par.molmax_prerun_fit = molmax;     
    else
        print('Roots in molnr curve are not real')
        return
    end
    
    %% plot molecule number within analysis region as function of recovery time
    figure
    hax = axes;
    hold on
    plot(var_rec, molnr_mean, '-o', 'Color', [0 0 0]);
    plot(molnr_fit);
    line([par.recovery_time par.recovery_time],get(hax,'YLim'),'Color',[0 0 1])
    xlabel('Recovery time / s')
    ylabel('Total number of molecules within analysis region')
    legend('Mean Number of Molecules','Fitted Curve (cubic polynomial)', 'Location', 'SouthEast')
    stringj = ['t_{rec} = ',num2str(par.recovery_time)];
    annotation('textbox', [0.7, 0.2, 0.1, 0.1], 'String', stringj)
    grid on
    hold off
    savefig(strcat('varpar_', num2str(par.t_bleach),'.fig')) % exchange t_bleach for the parameter, which is varied in the 'varpar' array

    %% additional simulation runs for determined optimal recovery time -> determines analysis region size for main simulation
    par.n_preruns = par.n_addruns;
    [par,molnr_bla] = analysis_roi_calculation_fit(par);
    par.molmax_prerun = molnr_bla;
        
    %% main simulation
    file=matfile(strcat(workingdir,'/sim_results_',datetoday,'_varpar_',num2str(varpar(kk),'%1.1f'),'.mat'),'writable', true);
    
    if check.A_figures
        % directory for A_figures
        % contains data of molecules within analysis region
        adir = strcat('A_figures_',num2str(varpar(kk),'%1.1f'));
        mkdir(adir);
    end
    
    %% repetition of the main simulation
    for run=1:par.n_mainruns
        disp(strcat('Simulation: ',num2str(kk),'/', num2str(length(varpar))))
        disp(run)
        disp(par)
        [results,Traj,par,A] = TOCCSL_main(par);
        % store results (kk=t_recovery, oo=run)
        all_results(run) = results;
        
        if check.A_figures
            %% save data for later figures
            fd = matfile(strcat(adir,'/A_',num2str(run),'.mat'),'Writable',true);
            fd.A = A;
        end
        toc
    end
    
    %% store results
    file.results=all_results;
    file.varpar=varpar;

end