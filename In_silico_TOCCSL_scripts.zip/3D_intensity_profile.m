clearvars

%% assign parameters
par.roi_x = 7;          % aperture side length in �m
par.roi_y = 7;          % aperture side length in �m
par.edge = 1;           % edge region with intensity decay (diffraction-affected laser profile) in �m, which is added to each side of the aperture
par.sigma_diff = 0.5;   % sigma for gaussian intensity decay at the aperture edges

%% calculate laser intensity in x and y direction
x_pos = 0:0.1:par.roi_x;
y_pos = 0:0.1:par.roi_y;

for posi = 1:length(x_pos)
    for posiy=1:length(y_pos)
        % diffraction in x-direction
        if x_pos(posi) <= par.roi_x/2           % if inside aperture-restricted area
            Z1 = 1;
        elseif x_pos(posi) > par.roi_x/2+par.edge
            Z1=0;
        elseif x_pos(posi) > par.roi_x/2        % if inside "edge" zone outside aperture-restricted area
            Z1 = exp(-(x_pos(posi)-(par.roi_x/2))^2/par.sigma_diff^2);
        end
        % diffraction in y-direction
        if y_pos(posiy) <= par.roi_y/2          % if inside aperture-restricted area
            Z2 = 1;
        elseif y_pos(posiy) > par.roi_y/2+par.edge
            Z1=0;
        elseif y_pos(posiy) > par.roi_y/2       % if inside "edge" zone outside aperture-restricted area
            Z2 = exp(-(y_pos(posiy)-(par.roi_y/2))^2/par.sigma_diff^2);
            
        end
        Z(posi,posiy)=Z1*Z2;
    end
end

%% plot 3D laser intensity profile
figure()
surf(x_pos,y_pos,Z)
title("laser intensity profile")
xlabel('\mum')
ylabel('\mum')
zlabel('normalized background-corrected laser intensity profile')
colorbar
box on
savefig(strcat('laser_profile.fig'))