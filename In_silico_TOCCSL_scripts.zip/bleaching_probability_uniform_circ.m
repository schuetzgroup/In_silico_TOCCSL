function P_bleach = bleaching_probability_uniform_circ(par,selector)
%% calculate the bleaching probability for fluorophores
% using formula from Axelrod et al.:
% c = c_0 * exp(- alpha * t_bleach * intensity);
% in double-exponential form -> two populations with
% different bleaching exponents (but each monoexponential)

% HERE: probabilities are calculated for all individual timesteps (second dimension of P_bleach)
% and all multi-exponential populations (first dimension of P_bleach)

% ALLOCATION
P_bleach = NaN(length(par.bleaching),par.steps_bleach);

switch selector
    case 'bleach'
        for i=1:size(P_bleach,1) % multi-exponential populations
            for j=1:par.steps_bleach
                P_bleach(i,j) = 1-(exp(-par.bleaching(i)*par.delta_t*1000*j));
            end
        end

        % space for other cases (e.g. readout at reduced laser power)
        % case 'readout'
end