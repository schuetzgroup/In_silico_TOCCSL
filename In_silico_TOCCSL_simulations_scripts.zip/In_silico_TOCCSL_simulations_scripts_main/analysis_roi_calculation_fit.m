function [par,molnr_roi] = analysis_roi_calculation_fit(par)
% fit density distribution for finding a cutoff for analysis region

%% calculate rho_value for fp_crit, Ruprecht et al
par.density_cutoff = -log(1-par.fp_crit)/(par.fp_limit^2*pi);

%% calculate further parameters
% total simulated time (important for array size!)
par.time = par.t_bleach/1000 + par.recovery_time;
% total number of molecules
par.partno = round(par.gridsize^2 * par.density);
% total number of steps in simulation (photobleaching + recovery)
par.stepno = round(ceil(par.t_bleach/1000*par.stepno_second)+par.recovery_time*par.stepno_second);
% time_step in seconds
par.delta_t = 1/par.stepno_second;

% Array for Trajectories (saves all molecules at all timesteps)
Traj=zeros(par.stepno,par.partno,4);

%% calculate mean square displacement through 2D-Einstein-Smoluchovski for each oligomer fractions
par.msd = zeros(par.n_nmer,1);
for ii_nmer=1:par.n_nmer
    par.msd(ii_nmer) = 4*par.D(ii_nmer)*par.delta_t;
end

%% laser parameters
% photobleaching parameters
if par.fluorophore
    switch par.fluorophore
        case 'GFP'
            par.bleaching(1) = 0.0442;
            par.bleaching(2) = 0.0056;
    end
elseif ~par.bleaching
    disp('no bleaching parameter!')
end

%% calculate time steps during bleaching process
par.steps_bleach = ceil(par.t_bleach/(par.delta_t*1000));
par.delta_t_bleach = par.t_bleach/par.steps_bleach;

%% assignment of oligomeric and fluorescent state (to particles in Traj array)
% calculate molecule number for each fraction
frac_partno = NaN(1,par.n_nmer);
for nn=1:par.n_nmer
    frac_partno(nn) = round(par.partno * par.fraction(nn));
end
% subtract particles from fractions if rounding errors occur
% starting at higher order oligomer fractions
bli=0;
while sum(frac_partno)~=par.partno
    frac_partno(end-bli)=frac_partno(end-bli)-1;
    bli=bli+1;
end

%% analysis region calculation - density based analysis region (concentric rings)
% coordinate x is the radius (density is calculated in rings with width=delta_x)

delta_x_local = 0.01; % resolution of density in micrometer
x_coo_local = 0:delta_x_local:par.roi_x*1.5;
COOR = NaN(par.n_preruns*(par.gridsize^2*par.density),2); % array for saving all coordinates of unbleached particles for #par.n_preruns runs

%% repetition of the same simulation
for run=1:par.n_preruns
    disp(['Prerun: ',num2str(run),'/', num2str(par.n_preruns)])
    %%%%%%%%%%%%%%%%%%%%%%%%%%% TOCCLS RUN %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % assign oligomeric and fluorescent state
    % first part of array are monomers, second dimers, etc...
    % here: starting with optimal labeling -> oligomeric state = fluorescent state
    for mm=1:par.n_nmer
        if mm==1
            indx_start = 1;
        else
            indx_start = sum(frac_partno(1:(mm-1)))+1;
        end
        indx_end = sum(frac_partno(1:mm));
        Traj(:,indx_start:indx_end,3:4) = mm;
    end
    
    %% allocation of starting position
    Traj(1,:,1:2) = rand(par.partno,2) * par.gridsize;
    
    %% stepsize calculation
    Traj = calculate_steps(Traj,par);
   
    %% cumulative sum of steps yield trajectories 
    Traj(:,:,1:2) = cumsum(Traj(:,:,1:2),1);
    
    %% boundary condition for trajectories
    Traj = boundary_condition(Traj,par);
    
    %% PHOTOBLEACHING PROCESS WITH SIMULTANEOUS DIFFUSION PROCESS
    if par.t_bleach > 0
        Traj = bleach(Traj,par);
    end
    
    % store results (kk=t_recovery, oo=run)
    check_fl = Traj(end,:,4) > 0; % check if fluorescent state is "on"
    COOR((run-1)*par.partno+1:(run-1)*par.partno+sum(check_fl),1) = Traj(end,check_fl,1);
    COOR((run-1)*par.partno+1:(run-1)*par.partno+sum(check_fl),2) = Traj(end,check_fl,2);
    
end

%% calculate density
COOR(isnan(COOR(:,1)),:)=[]; % get rid of empty entries because array is initialized for maximum particle number
COOR(:,:) = abs(COOR(:,:)-par.gridsize/2); % absolute value of distance to center for x and y coordinate

%% calculate "local" density (for individual rings)

for gg=1:length(x_coo_local)-1
    
    loc1 = COOR(:,1).^2 + COOR(:,2).^2 <= x_coo_local(gg).^2; % circular
    loc2 = COOR(:,1).^2 + COOR(:,2).^2 <= x_coo_local(gg+1).^2; % circular
    locloc = loc2 & ~loc1;
    
    partcount_local(gg) = sum(locloc)/par.n_preruns;
    area_local(gg) = x_coo_local(gg+1)^2*pi - x_coo_local(gg)^2*pi; % circular
    density_local(gg) = partcount_local(gg)/area_local(gg);
end

%DENS_local(kk,:) = density_local;
DENS_local = density_local;

for k=1:(length(x_coo_local)-1)
    x_coo_cent(k) = (x_coo_local(k)+x_coo_local(k+1))/2;
end

[fitres, gof] = fit_density_erf(x_coo_cent, DENS_local,par);

x_fit_grid = x_coo_local;
dens_fit_grid = fitres(x_fit_grid);

%% calculate mean FP rate in analysis region with fit data
fp_rate_local_fit = 1-exp(-par.fp_limit^2*pi.*dens_fit_grid);
fp_rate_mean_fit = cumsum(fp_rate_local_fit.*dens_fit_grid)./cumsum(dens_fit_grid);

%% cutoff for analysis region
% evaluate curve fit on a grid in x
[mincut, mincut_index] = min(abs(dens_fit_grid-par.density_cutoff));
par.roi_crit_x = 2 * x_coo_local(mincut_index);
par.roi_crit_y = par.roi_crit_x; % diameter of analysis region

% mean FP rate in analysis region
% fp_rate_mean_crit = fp_rate_mean(mincut_index)
par.fp_rate_mean_crit_fit = fp_rate_mean_fit(mincut_index);

%% recovery time selection
% number of molecules in analysis region as output
molnr_roi = sum(partcount_local(1:mincut_index));

%% plot density fit and roi_size
figure
hax = axes;
%plot(x_coo_smooth,dens_smooth,'LineWidth',3);
h = plot(x_coo_local(2:end), DENS_local, 'LineWidth', 1, 'Color', [0 0 0]);
%plot(x_coo_local(2:end),DENS_local);
hold on
plot(fitres);
%plot(x_coo_cent, DENS_local);
title({'100 dimers/\mum^2'; 'D1 = 0.5\mum^2/s, D2 = D1/D2*0.5\mum^2/s, 0.2<D1/D2<1'; 'laser shape: diffraction'; 'aperture = 7x7 \mum^2, grid = 3x aperture'; 'FP radius = 300nm, FP limit = 20%'})
line([par.roi_crit_x/2 par.roi_crit_x/2],get(hax,'YLim'),'Color',[0 0 1])
line(get(hax,'XLim'),[par.density_cutoff par.density_cutoff],'Color',[0 1 0])
legend('Mean Density (conc. rings)', 'Fitted Density (err. functions)', 'Analysis ROI Radius Cutoff', 'Density Cutoff (Ruprecht)', 'Location', 'NorthWest' );
xlabel('Radius ROI / \mum')
ylabel('Density / molecules/\mum�')
xlim([0, 10]);
ylim([0, 120]);
stringi = ['Radius Analysis ROI = ',num2str(par.roi_crit_x/2)];
stringk = ['Density Cutoff = ',num2str(par.density_cutoff)];
annotation('textbox', [0.55, 0.1, 0.1, 0.1], 'String', stringi);
annotation('textbox', [0.55, 0.18, 0.1, 0.1], 'String', stringk);
grid on
hold off
savefig(strcat('density_fit_varpar', num2str(par.roi_x), '_trec_', num2str(par.recovery_time), '.fig'))