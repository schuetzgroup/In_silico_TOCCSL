function [fitresult, gof] = fit_molnr_vs_rectime(x1, y1)
%  Inpput data for fit:
%      X Input : x1
%      Y Output: y1
%  Output:
%      fitresult : a fit object representing the fit.
%      gof : structure with goodness-of fit info.
%  See also FIT, CFIT, SFIT.

%% Fit: 'untitled fit 1'.
[xData, yData] = prepareCurveData( x1, y1 );

% Set up fittype and options.
ft = fittype('poly3');

% Fit model to data.
[fitresult, gof] = fit( xData, yData, ft );