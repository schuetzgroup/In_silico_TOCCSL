function Traj=bleach(Traj,par)
% "bleach" particles within the aperture-restricted region
% if bleached --> set fluor. variable to 0)
% adjust bleaching by "par.t_bleach" and "par.bleaching"

switch par.laser_shape
    case 'uniform'
        P_bleach = bleaching_probability_uniform_circ(par,'bleach');
        
        for index_particle=1:par.partno
            % logical arrays for finding out if particles are "inside" the laser
            % beam and how long they have been in the illuminated area
            check.inside = ((abs(Traj(1:par.steps_bleach,index_particle,1)-par.gridsize/2)).^2 + ...
                (abs(Traj(1:par.steps_bleach,index_particle,2)-par.gridsize/2)).^2) <= (par.roi_x/2)^2;
            
            %calculate p_bleach for whole time inside laser beam
            if any(check.inside)
                for num_fluor=1:Traj(par.steps_bleach,index_particle,4)
                    mc=rand;
                    if mc <= P_bleach(sum(check.inside)) % probability dependent on time in laserROI
                        Traj(par.steps_bleach:end,index_particle,4) = Traj(par.steps_bleach:end,index_particle,4)-1;
                    end
                end
            end
        end
        
    case 'diffraction'
        for time=1:par.steps_bleach
            check.inside = ((abs(Traj(time,:,1)-par.gridsize/2)).^2 + ...
                (abs(Traj(time,:,2)-par.gridsize/2)).^2) <= (par.roi_x/2+par.edge)^2 ...
                & Traj(time,:,4)>0;

            Traj_inside = Traj(time,check.inside,:);
            
            for particle=1:size(Traj_inside,2)
                x_pos = abs(Traj_inside(1,particle,1)-par.gridsize/2); % position with 0 at center of ROI
                y_pos = abs(Traj_inside(1,particle,2)-par.gridsize/2);
                P_bleach = bleaching_probability_diffraction_circ(x_pos,y_pos,par);
                for num_fluor=1:Traj_inside(1,particle,4)
                    mc=rand;
                    if mc <= P_bleach
                        Traj_inside(1,particle,4)=Traj_inside(1,particle,4)-1;
                    end
                end
            end
            
            % write bleached particles in Traj array
            for trans = 1:(size(Traj,1)-time+1)
                Traj(time+trans-1,check.inside,4)=Traj_inside(1,:,4);
            end
        end
        
    case 'ideal'
        % ideal bleaching of molecules
        % if molecule is inside the aperture for at least 1 time step, it is
        % instantly photobleached
        
        for index_particle=1:par.partno
            check.inside = ((abs(Traj(1:par.steps_bleach,index_particle,1)-par.gridsize/2)).^2 + ...
                (abs(Traj(1:par.steps_bleach,index_particle,2)-par.gridsize/2)).^2) <= (par.roi_x/2)^2;            
            check.inside_time = cumsum(double(check.inside));         
            if any(check.inside)
                Traj(par.steps_bleach:end,index_particle,4) = 0;
            end
        end        
end