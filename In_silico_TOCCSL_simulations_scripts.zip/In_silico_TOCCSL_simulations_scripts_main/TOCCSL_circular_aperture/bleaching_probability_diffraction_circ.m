function P_bleach = bleaching_probability_diffraction_circ(x_pos,y_pos,par)
% calculate the bleaching probability for fluorophores
% using formula from Axelrod et al.:
% c = c_0 * exp(- alpha * t_bleach * intensity);
% in double-exponential form.
% Intensity of Laser has diffraction profile
% I=1 in the center region
% I = Gaussian shaped in edge zone

pos_radius = sqrt((x_pos)^2 + (y_pos)^2);
if pos_radius  <= par.roi_x/2 % inner region
    Z = 1;
elseif pos_radius > par.roi_x/2 % if inside "edge" region
    Z = exp(-(pos_radius-(par.roi_x/2))^2/par.sigma_diff^2);
end

P_bleach = 1 -(0.782*exp(-par.intensity*Z*par.bleaching(1)*par.delta_t*1000)+0.2180*exp(-par.intensity*Z*par.bleaching(2)*par.delta_t*1000));