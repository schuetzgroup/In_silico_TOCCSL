function [results,Traj,par,A] = TOCCSL_main(par_input)
% clearvars -except par_input
% close all hidden

%% INPUT PARAMETERS
if nargin == 1  % check if input parameters are parsed via function argument
    par=par_input;
    par.plots_signal=1;
else
        %% assign parameters
        par.n_preruns = 100;                % number of simulations for recovery time selection
        par.n_nmer = 2;                     % number of oligomeric fractions
        par.fraction = [0.5 0.5];               % 100% dimers
        %par.fraction = [0.5 0.5];          % 50% monomers / 50% dimers
        %par.fraction = [0 0 0 1];          % 100% tetramers
        par.D = [0.5 0.5];                  % D = 0.5�m�/s
        %par.D = [0 0.1];                   % D = 0.1�m�/s
        %par.D = [0 0.02];                  % D = 0.02�m�/s
        %par.D = [0 varpar(kk)];            % variation of D (100% dimers)
        %par.D = [0 0 0 varpar(kk)];        % variation of D (100% tetramers)
        %par.D = [0.5 0.5*varpar(kk)];      % variation of D2/D1 (50% monomers / 50% dimers)
        par.roi_x = 7;                      % aperture side length = 7�m
        par.roi_y = 7;                      % aperture side length = 7�m
        %par.roi_x = varpar(kk);            % variation of aperture side length 
        %par.roi_y = varpar(kk);            % variation of aperture side length 
        par.d_ap = min(par.roi_x,par.roi_y);
        par.density = 100;                  % surface density of molecules
        par.t_bleach = 4000;                 % in ms
        % par.t_bleach = 4000;              % photobleaching time = 4s
        par.recovery_time = 0;              % in s, variation of recovery time
        par.stepno_second = 300;            % simualted time steps per second
        par.sigma_xy = 0;
        par.laser_shape = 'diffraction';    % laser intensity profile: 'diffraction', 'uniform', 'ideal'
        par.fluorophore = 'GFP';            % photobleaching parameters from GFP bleaching curves
        par.intensity = 5.32;               % laser intensity (from experiment)
        par.res_limit = 0.300;              
        par.wavelength = 488;               % laser wavelength (from experiment)
        par.gridsize = 3*par.roi_y;         % side length of cell
        par.fp_limit = 0.300;               % threshold distance between molecules for false n-mer determination
        par.fp_crit = 0.20;                 % maximum false n-mer rate
        par.analysis_method = 'everything'; % all molecules are considered for analysis, including false n-mers
        par.edge = 1;                       % edge region with intensity decay (diffraction-affected laser profile)
        par.sigma_diff=0.5;                 % sigma for half-gaussian intensity decay at the edges
        par.roi_crit_x = 2;
        par.roi_crit = 2;
        par.plots_signal = 1;               % show plots if signal is set to 1

        % define edge zone for "diffraction" bleaching mode
        % par.edge: is added to each side of the aperture
        % par.sigma: for gaussian shaped edge region of laser profile, 0.5 is an appropriate value for par.edge =1
        % check laser profile with "check_laser_profile.m"
end

%% CALCULATE FURTHER PARAMETERS

% total simulated time (important for array size!)
par.time = par.t_bleach/1000 + par.recovery_time;
% total number of particles
par.partno = round(par.gridsize^2 * par.density);
% total number of steps in simulation (photobleaching + recovery)
par.stepno = round(ceil(par.t_bleach/1000*par.stepno_second)+par.recovery_time*par.stepno_second);
% time_step in seconds
par.delta_t = 1/par.stepno_second;

% Array for Trajectories (saves all particles at all timesteps)
% If all trajectory steps are not required, the Traj-array could be used
% only for the bleaching time, then the new coordinates could be parsed and
% the recovery trajectories could be calculated afterwards. Only the
% positions and properties at the end of recovery would be needed. The rest
% could be deleted, if only little RAM available.
Traj=zeros(par.stepno,par.partno,4);

% calculate mean square displacement through 2D-Einstein-Smoluchovski for different oligomer fractions
par.msd = zeros(par.n_nmer,1);
for ii_nmer=1:par.n_nmer
    par.msd(ii_nmer) = 4*par.D(ii_nmer)*par.delta_t;
end

%% Photobleaching parameters
if par.fluorophore
    switch par.fluorophore
        case 'GFP'
            par.bleaching(1) = 0.0442; % 0.2352/5.32
            par.bleaching(2) = 0.0056; % 0.0297/5.32
        
        % ...
        % space for parameters of other fluorescent labels
        % attention: values for two-component exponential fit are currently
        % hard-coded in "bleaching_probability" functions!

        % case 'XXX'
            % par.bleaching(1) = 0.003;
            % par.bleaching(2) = 0.002;
    end

elseif ~par.bleaching
    disp('no bleaching parameter!')
end

% calculate time steps during bleaching process
par.steps_bleach = ceil(par.t_bleach/(par.delta_t*1000));
par.delta_t_bleach = par.t_bleach/par.steps_bleach;

%% ASSIGNMENT of OLIGOMERIC AND FLUORESCENT STATE (to molecules in Traj array)

% calculate particle number for each fraction
frac_partno = NaN(1,par.n_nmer);
for nn=1:par.n_nmer
    frac_partno(nn) = round(par.partno * par.fraction(nn));
end
% subtract particles from fractions if rounding errors occur starting at higher order oligomer fractions
bli=0;
while sum(frac_partno)~=par.partno
    frac_partno(end-bli)=frac_partno(end-bli)-1;
    bli=bli+1;
end

% assign oligomeric and fluorescent state
% first part of array are monomers, second dimers, etc...
% here: starting with optimal labeling -> oligomeric state = fluorescent state

for mm=1:par.n_nmer
    if mm==1
        indx_start = 1;
    else
        indx_start = sum(frac_partno(1:(mm-1)))+1;
    end
    indx_end = sum(frac_partno(1:mm));
    Traj(:,indx_start:indx_end,3:4) = mm;
end

%% ALLOCATION of STARTING POSITIONS
Traj(1,:,1:2) = rand(par.partno,2) * par.gridsize;

%% STEPSIZE CALCULATION
Traj = calculate_steps(Traj,par); % faster than calculation of radial probability

%% CUMULATIVE SUM OF STEPS YIELD TRAJECTORIES
Traj(:,:,1:2) = cumsum(Traj(:,:,1:2),1);

%% BOUNDARY CONDITION FOR TRAJECTORIES
Traj = boundary_condition(Traj,par);

%% BLEACHING PROCESS WITH SIMULTANEOUS DIFFUSION PROCESS
if par.t_bleach > 0
    Traj = bleach_circ(Traj,par);
end

%% CLEAN-UP
clearvars -except Traj par

%% ANALYSIS OF IMPACT ON WHOLE CELL

PBP = sum(Traj(end,:,3)~=Traj(end,:,4) & Traj(end,:,4)~=0); % partially bleached particles
FBP = sum(Traj(end,:,4)==0); % fully bleached
NBP = sum(Traj(end,:,3)==Traj(end,:,4)); % not bleached

if PBP+FBP+NBP ~= size(Traj,2)
    disp('error in analysis of Bleached Particles!!!!')
end

results.num_partially_bleached = PBP;
results.num_fully_bleached = FBP;
results.total_particle_number = size(Traj,2);

%% ACCOUNT FOR RESOLUTION LIMIT & FALSE POSITIVES
% evaluate molecules within analysis region

switch par.analysis_method
    case 'everything'
        [A,WS_simple,WS_wo_FP,WS_FP_detail,FP_count] = FP_cluster_analysis(Traj,par);
        results.WS_simple = WS_simple;
        results.FP_count = FP_count;
        results.WS_wo_FP = WS_wo_FP;
        results.WS_FP_detail = WS_FP_detail;

    % case 'alternative'
    % space for alternative analysis methods (other
    % shapes of analysis region, ...)

end

%% STORE PARAMETERS IN RESULTS
results.parameters = par;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%% END OF SIMULATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% PLOT non-resolvable molecules
if par.plots_signal == 2
    % non-resolvable particle discrimination for the plot
    for ii=1:size(A,1)
        dist=sqrt((abs(A(ii,1)-A(:,1))).^2 + (abs(A(ii,2)-A(:,2))).^2);
        dist(ii)=[]; dist=dist-par.fp_limit;
        if any(dist < par.fp_limit)
            A(ii,4)=-1;
        end
    end

    t_plot = size(Traj,1); %size(Traj,1); %par.steps_bleach;
    markersize = 10;
        
    figure()
    hold on
    hdimer = line(Traj(t_plot,Traj(t_plot,:,4)==2,1),Traj(t_plot,Traj(t_plot,:,4)==2,2));
    hmono = line(Traj(t_plot,Traj(t_plot,:,4)==1,1),Traj(t_plot,Traj(t_plot,:,4)==1,2));
    plot(A(A(:,5)>0,1),A(A(:,5)>0,2),'ok')
    hold off

    title("Non-resolvable molecules")
    
    hmono.LineStyle = 'none';
    hmono.Marker = '.';
    hmono.MarkerSize = markersize;
    hmono.MarkerEdgeColor = 'red'; %[0.9 0.1 0.2];
    hmono.MarkerFaceColor = 'red'; %[0 0 0];
    
    hdimer.LineStyle = 'none';
    hdimer.Marker = '.';
    hdimer.MarkerSize = markersize;
    markercol2 = [0.1 0.4 0.8];
    hdimer.MarkerEdgeColor = markercol2;
    hdimer.MarkerFaceColor = markercol2;
    
    %set(gca,'Visible','off'); % 'XTickLabel','','YTickLabel','','TickLength',[0 0]);
    
    % xticks(0:1:par.gridsize);
    % yticks(0:1:par.gridsize);
    %
    xlim([par.gridsize/2-7 par.gridsize/2+7]);
    ylim([par.gridsize/2-7 par.gridsize/2+7]);
    
    % gi = 1:1:14;
    % gi=gi';
    % xticklab = cellstr(num2str(gi));
    % xticklabels(xticklab);
    
    % rectangle
    % pos=[par.gridsize/2-roisize par.gridsize/2-roisize 2*roisize 2*roisize];
    % rectangle('Position',pos)
    
    % legend
    % legend([hdimer,hmono,hres],{'Dimer','Incompletely bleached dimer','Analyzed particles'},'FontSize',12)
    % legend([hdimer,hmono],{'Unbleached Dimer','Partially Bleached Dimer'},'FontSize',12)
    
    ax = gca;
    ax.XTickMode = 'manual';
    ax.YTickMode = 'manual';
    ax.ZTickMode = 'manual';
    ax.XLimMode = 'manual';
    ax.YLimMode = 'manual';
    ax.ZLimMode = 'manual';
    
    fig = gcf;
    fig.PaperUnits = 'centimeters';
    fig.PaperPosition = [0 0 10 10];

    % saveas(gcf,'analysis.eps','epsc');
end

%% PLOT POSTBLEACH IMAGE (only works up to dimers)
if par.plots_signal == 1  
    t_plot = par.steps_bleach; %size(Traj,1); %par.steps_bleach;
    markersize = 10;

    figure()
    hold on
    hdimer = line(Traj(t_plot,Traj(t_plot,:,4)==2,1),Traj(t_plot,Traj(t_plot,:,4)==2,2));
    hmono = line(Traj(t_plot,Traj(t_plot,:,4)==1,1),Traj(t_plot,Traj(t_plot,:,4)==1,2));
    hold off

    title('Post-bleach image')
    
    hmono.LineStyle = 'none';
    hmono.Marker = '.';
    hmono.MarkerSize = markersize;
    hmono.MarkerEdgeColor = 'red'; %[0.9 0.1 0.2];
    hmono.MarkerFaceColor = 'red'; %[0 0 0];
    
    hdimer.LineStyle = 'none';
    hdimer.Marker = '.';
    hdimer.MarkerSize = markersize;
    markercol2 = [0.1 0.4 0.8];
    hdimer.MarkerEdgeColor = markercol2;
    hdimer.MarkerFaceColor = markercol2;
    
    % xticks(0:1:par.gridsize);
    % yticks(0:1:par.gridsize);
    xlim([par.gridsize/2-7 par.gridsize/2+7]);
    ylim([par.gridsize/2-7 par.gridsize/2+7]);
    
    % gi = 1:1:14;
    % gi=gi';
    % xticklab = cellstr(num2str(gi));
    % xticklabels(xticklab);
    
    rectangle
    pos=[par.gridsize/2-(par.roi_x/2+par.edge) par.gridsize/2-(par.roi_y/2+par.edge) par.roi_x+2*par.edge par.roi_y+2*par.edge];
    rectangle('Position',pos)

    ax = gca;
    ax.XTickMode = 'manual';
    ax.YTickMode = 'manual';
    ax.ZTickMode = 'manual';
    ax.XLimMode = 'manual';
    ax.YLimMode = 'manual';
    ax.ZLimMode = 'manual';
    
    fig = gcf;
    fig.PaperUnits = 'centimeters';
    fig.PaperPosition = [0 0 10 10];
    % saveas(gcf,'postbleach.eps','epsc');
end

%% plot last image (recovery check)
if par.plots_signal == 1
    t_plot = size(Traj,1);
    figure()
    title('Recovery check after t_{rec}')
    hold on
     plot(Traj(t_plot,Traj(t_plot,:,4)==1,1),Traj(t_plot,Traj(t_plot,:,4)==1,2),'.', 'Markersize', 5);
     plot(Traj(t_plot,Traj(t_plot,:,4)==2,1),Traj(t_plot,Traj(t_plot,:,4)==2,2),'.', 'Markersize', 5,'MarkerEdgeColor', [0.8500 0.3250 0.0980], 'MarkerFaceColor', [0.8500 0.3250 0.0980]);
     plot(Traj(t_plot,Traj(t_plot,:,4)==3,1),Traj(t_plot,Traj(t_plot,:,4)==3,2),'.', 'Markersize', 5);
     plot(Traj(t_plot,Traj(t_plot,:,4)==4,1),Traj(t_plot,Traj(t_plot,:,4)==4,2),'.', 'Markersize', 5);
     xlim([0 par.gridsize])
     ylim([0 par.gridsize])
      phi= 0:pi/100:2*pi;
      x0 = par.gridsize/2;
      y0 = par.gridsize/2;
      r = par.roi_crit_x/2;
      xc = x0+r*cos(phi);
      yc = y0+r*sin(phi);
%      plot(xc,yc,'.', 'Markersize', 3, 'MarkerEdgeColor', 'cyan', 'MarkerFaceColor', 'cyan')
%      hold on;
%      r2 = 0.7;
%      xc2 = x0+r2*cos(phi);
%      yc2 = y0+r2*sin(phi);
%      plot(xc2,yc2,'.','MarkerSize',3, 'MarkerEdgeColor', 'black', 'MarkerFaceColor', 'black')
%      r3 = 1.0;
%      xc3 = x0+r3*cos(phi);
%      yc3 = y0+r3*sin(phi);
%      plot(xc3,yc3,'.','MarkerSize',3, 'MarkerEdgeColor', 'black', 'MarkerFaceColor', 'black')
%      r4 = 1.3;
%      xc4 = x0+r4*cos(phi);
%      yc4 = y0+r4*sin(phi);
%      plot(xc4,yc4,'.','MarkerSize',3, 'MarkerEdgeColor', 'black', 'MarkerFaceColor', 'black')
%      r5 = 1.6;
%      xc5 = x0+r5*cos(phi);
%      yc5 = y0+r5*sin(phi);
%      plot(xc5,yc5,'.','MarkerSize',3, 'MarkerEdgeColor', 'black', 'MarkerFaceColor', 'black')   
%      r6 = 0.4;
%      xc6 = x0+r6*cos(phi);
%      yc6 = y0+r6*sin(phi);
%      plot(xc6,yc6,'.','MarkerSize',3, 'MarkerEdgeColor', 'black', 'MarkerFaceColor', 'black')  
%      r7 = 0.1;
%      xc7 = x0+r7*cos(phi);
%      yc7 = y0+r7*sin(phi);
%      plot(xc7,yc7,'.','MarkerSize',3, 'MarkerEdgeColor', 'black', 'MarkerFaceColor', 'black')  
       axis equal
        xlim([3.5 17.5])       
        ylim([3.5 17.5])
%       xlim([0 21])       
%       ylim([0 21])
       hold off
end

%% PLOT sim incl bleaching process
if par.plots_signal == 1    
    for ii=1:10:par.stepno %par.steps_bleach-1:100:par.stepno % par.steps_bleach+1 % plot every 100 time steps
        for nmer=1:par.n_nmer
            range_fl(nmer,:) = Traj(ii,:,4)==nmer;   % mask for number of fluorophores
            range_nmer(nmer,:) = Traj(ii,:,3)==nmer;  % mask for type of nmer
        end
        for nmer=1:par.n_nmer
            for nfl=1:par.n_nmer
                range_nmer_fl(nmer,nfl,:) = range_nmer(nmer,:) & range_fl(nfl,:);  % combinated mask for nmers with a certain number of fluorophores
            end
        end        
        legend_entries=cell(par.n_nmer,1);
        for ent=1:par.n_nmer
            legend_entries{ent}=num2str(ent);
        end
        figu = 10:1:10+par.n_nmer;        
        for indi=1:par.n_nmer % indi=2 if only dimers should be shown
            range_leg=zeros(1,par.n_nmer);
            hand=0;
            ind=indi;
            figure(figu(indi)); 
            clf
            bla=gcf;
            bla.Position=[(indi-1)*350+indi*10 200 350 350];
            title(strcat('Nmer Fraction: ',num2str(indi)))
            xlim([0 par.gridsize])
            ylim([0 par.gridsize])
            hold on
            for nfl=1:par.n_nmer
                h=plot(Traj(ii,range_nmer_fl(ind,nfl,:),1),Traj(ii,range_nmer_fl(ind,nfl,:),2),'.'); %, 'MarkerEdgeColor', [0.8500 0.3250 0.0980], 'MarkerFaceColor', [0.8500 0.3250 0.0980]);
                if size(h,1)==1
                    hand=hand+1;
                    range_leg(nfl)=1;
                    hh(hand)=h;
                end
            end
            leg=legend_entries(logical(range_leg));
            if any(range_leg)
                legend(hh,leg);
            end
            hold off
            clear hh range_leg leg
        end
        pause(1)
        if ii==par.steps_bleach-1
            waitforbuttonpress;
        end        
        % waitforbuttonpress;
    end
end