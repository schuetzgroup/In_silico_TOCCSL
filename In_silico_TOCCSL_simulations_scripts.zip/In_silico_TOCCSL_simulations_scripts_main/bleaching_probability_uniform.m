function P_bleach = bleaching_probability_uniform(par,selector)
% calculate the bleaching probability for fluorophores
% using formula from Axelrod et al.:
% c = c_0 * exp(- alpha * t_bleach * intensity);
% in double-exponential form.

% ALLOCATION
P_bleach = NaN(1,par.steps_bleach);
    
    switch selector
        case 'bleach'
            for i=1:par.steps_bleach
                %double component exponential probability
                P_bleach(i) = 1 -(0.782*exp(-par.intensity *par.bleaching(1)*par.delta_t*1000*i)+0.2180*exp(-par.intensity *par.bleaching(2)*par.delta_t*1000*i));
            end
    
            % space for other cases (e.g. readout at reduced laser power)
            % case 'readout'
    end
end